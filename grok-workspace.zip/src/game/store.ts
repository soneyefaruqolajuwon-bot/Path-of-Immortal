import { create } from "zustand";
import type { DaoId, Gender, Origin, PlaceId, ScreenId, TimeSpeed } from "./types";
import type { GameState } from "./types";
import {
  awakenArtifact, beginTravel, blackBuy, combatHit, cultivate, digRuin, doActivity, enterInner,
  foundSect, go, innerPick, joinBattle, joinSect, levy, march, newGame, pressOn, previewSkip,
  sandbox, sectWork, setSpeed, skipYears, spendHours, startCombat, talkTo, tick, tryBreak,
} from "./engine";
import { loadGame, saveGame, wipeSave } from "./save";

type Store = {
  s: GameState | null;
  boot: () => void;
  create: (o: { name: string; gender: Gender; origin: Origin; dao: DaoId }) => void;
  wipe: () => void;
  go: (id: ScreenId) => void;
  tick: (ms: number) => void;
  act: (id: string) => void;
  talk: (id: string, k: "kind" | "gift" | "insult" | "recruit" | "scheme") => void;
  travel: (to: PlaceId) => void;
  press: () => void;
  cult: (h: number) => void;
  brk: () => void;
  hit: (st: "strike" | "technique" | "flee") => void;
  join: (sect: string) => void;
  hall: (h: string) => void;
  found: (n: string, d: string) => void;
  warMarch: (id: string) => void;
  warFight: (id: string) => void;
  tax: () => void;
  speed: (sp: TimeSpeed) => void;
  askSkip: (y: number) => void;
  doSkip: () => void;
  cancelSkip: () => void;
  buy: (item: string, c: number) => void;
  artifact: () => void;
  ruin: () => void;
  inner: () => void;
  innerGo: (i: number) => void;
  fight: (name: string) => void;
  box: (cmd: string) => void;
  hours: (h: number) => void;
};

function persist(s: GameState) {
  saveGame(s);
  return { s: { ...s, player: { ...s.player }, world: { ...s.world } } };
}

export const useGame = create<Store>((set, get) => ({
  s: null,
  boot: () => set({ s: loadGame() }),
  create: (o) => set(persist(newGame(o))),
  wipe: () => { wipeSave(); set({ s: null }); },
  go: (id) => { const s = get().s; if (!s) return; go(s, id); set(persist(s)); },
  tick: (ms) => { const s = get().s; if (!s) return; tick(s, ms); set({ s }); },
  act: (id) => { const s = get().s; if (!s) return; doActivity(s, id); set(persist(s)); },
  talk: (id, k) => { const s = get().s; if (!s) return; talkTo(s, id, k); set(persist(s)); },
  travel: (to) => { const s = get().s; if (!s) return; beginTravel(s, to); set(persist(s)); },
  press: () => { const s = get().s; if (!s) return; pressOn(s); set(persist(s)); },
  cult: (h) => { const s = get().s; if (!s) return; cultivate(s, h); set(persist(s)); },
  brk: () => { const s = get().s; if (!s) return; tryBreak(s); set(persist(s)); },
  hit: (st) => { const s = get().s; if (!s) return; combatHit(s, st); set(persist(s)); },
  join: (sect) => { const s = get().s; if (!s) return; joinSect(s, sect); set(persist(s)); },
  hall: (h) => { const s = get().s; if (!s) return; sectWork(s, h); set(persist(s)); },
  found: (n, d) => { const s = get().s; if (!s) return; foundSect(s, n, d); set(persist(s)); },
  warMarch: (id) => { const s = get().s; if (!s) return; march(s, id); set(persist(s)); },
  warFight: (id) => { const s = get().s; if (!s) return; joinBattle(s, id); set(persist(s)); },
  tax: () => { const s = get().s; if (!s) return; levy(s); set(persist(s)); },
  speed: (sp) => { const s = get().s; if (!s) return; setSpeed(s, sp); set(persist(s)); },
  askSkip: (y) => { const s = get().s; if (!s) return; previewSkip(s, y); set(persist(s)); },
  doSkip: () => { const s = get().s; if (!s) return; if (s.confirmSkip) skipYears(s, s.confirmSkip.years); set(persist(s)); },
  cancelSkip: () => { const s = get().s; if (!s) return; s.confirmSkip = null; set(persist(s)); },
  buy: (item, c) => { const s = get().s; if (!s) return; blackBuy(s, item, c); set(persist(s)); },
  artifact: () => { const s = get().s; if (!s) return; awakenArtifact(s); set(persist(s)); },
  ruin: () => { const s = get().s; if (!s) return; digRuin(s); set(persist(s)); },
  inner: () => { const s = get().s; if (!s) return; enterInner(s); set(persist(s)); },
  innerGo: (i) => { const s = get().s; if (!s) return; innerPick(s, i); set(persist(s)); },
  fight: (name) => { const s = get().s; if (!s) return; startCombat(s, name); set(persist(s)); },
  box: (cmd) => { const s = get().s; if (!s) return; sandbox(s, cmd); set(persist(s)); },
  hours: (h) => { const s = get().s; if (!s) return; spendHours(s, h); set(persist(s)); },
}));
