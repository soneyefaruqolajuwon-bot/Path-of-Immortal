import type {
  Activity, DaoId, FoundationGrade, GameState, Gender, Npc, Origin, PlaceId, ScreenId, TimeSpeed,
} from "./types";
import {
  DAO, FACTIONS, FOUNDATION_MUL, HOURS_YEAR, JOBS, MS_PER_GAME_DAY, NAMED_NPCS, PLACE, PLACES, SAVE_VERSION,
  SECTS, lifespanOf, portraitOf, qiNeed, realmLabel,
} from "./data";

const uid = () => Math.random().toString(36).slice(2, 9);

export function calendar(hours: number) {
  const y = EPOCH(hours);
  const dayOfYear = Math.floor((hours / 24) % 360);
  const month = Math.floor(dayOfYear / 30) + 1;
  const day = (dayOfYear % 30) + 1;
  const tod = Math.floor(hours % 24);
  const week = (Math.floor(dayOfYear / 6) % 6) + 1;
  return { year: y, month, day, hour: tod, week, totalDays: Math.floor(hours / 24) };
}
function EPOCH(h: number) {
  return 614 + Math.floor(h / HOURS_YEAR);
}

function fx(s: GameState, t: string) {
  s.log = [t, ...s.log].slice(0, 80);
  s.world.history = [t, ...s.world.history].slice(0, 200);
}

function rumor(s: GameState, text: string, truth = true) {
  s.world.rumors.unshift({ text, true: truth, age: 0 });
  s.world.rumors = s.world.rumors.slice(0, 40);
}

export function powerOf(s: GameState) {
  const p = s.player;
  const fm = FOUNDATION_MUL[p.foundation] ?? 1;
  return Math.floor((20 + p.realm * 18 + p.stage * 4) * fm * (1 + p.techniques.length * 0.08));
}

export function npcPower(n: Npc) {
  return 12 + n.realm * 16 + Math.floor(n.age / 20);
}

function extraNpcs(): Npc[] {
  const jobs = ["scribe", "guard", "cook", "beggar", "priest", "smuggler", "alchemist", "innkeep", "soldier", "child"];
  const places = PLACES.map((p) => p.id);
  const out: Npc[] = [];
  for (let i = 0; i < 36; i++) {
    const place = places[i % places.length]!;
    const g: Gender = i % 2 ? "female" : "male";
    out.push({
      id: "n" + i,
      name: ["Ash", "Lin", "Wei", "Yun", "Mei", "Hao", "Qiu", "Shen"][i % 8] + " " + ["of Dust", "of Coil", "of Salt", "of Cloud", "of Bell", "of Fen"][i % 6],
      title: jobs[i % jobs.length]!,
      portrait: g === "female" ? "/art/hero-female-commoner.png" : "/art/hero-male-commoner.png",
      place,
      job: jobs[i % jobs.length]!,
      realm: Math.floor(i / 8),
      wealth: 8 + (i * 17) % 400,
      age: 12 + (i * 13) % 80,
      gender: g,
      faction: FACTIONS[i % FACTIONS.length]!,
      goal: "Survive the year.",
      destiny: i % 9 === 0 ? "Hidden heir" : "Ordinary thread",
      loyalty: 40 + (i * 7) % 50,
      memory: [],
      alive: true,
      schedule: ["sleep", "work", "eat", "cultivate", "market"][Math.floor((i % 24) / 5)] ?? "work",
      relation: 0,
    });
  }
  return out;
}

export function newGame(opts: { name: string; gender: Gender; origin: Origin; dao: DaoId }): GameState {
  const foundation: FoundationGrade = opts.origin === "royal" ? "solid" : "ordinary";
  const named: Npc[] = NAMED_NPCS.map((n) => ({
    ...n, loyalty: 50, memory: [], alive: true, relation: 0, rival: n.id === "kael",
  }));
  const s: GameState = {
    v: SAVE_VERSION,
    screen: "home",
    player: {
      name: opts.name.trim() || "Unnamed",
      gender: opts.gender,
      origin: opts.origin,
      dao: opts.dao,
      realm: opts.origin === "royal" ? 1 : 0,
      stage: 1,
      qi: 0,
      foundation,
      lastBreak: "none",
      gold: opts.origin === "royal" ? 800 : 40,
      age: opts.origin === "royal" ? 18 : 16,
      lifespan: lifespanOf(opts.origin === "royal" ? 1 : 0, foundation),
      karma: 0,
      place: opts.origin === "royal" ? "coil_palace" : "ashroot",
      sect: "",
      rank: "none",
      wanted: 0,
      alias: "",
      identityHidden: false,
      soul: [],
      legend: { ashroot: "A nobody from the well." },
      mandate: opts.origin === "royal" ? 20 : 0,
      disciples: [],
      master: "",
      companion: "",
      artifacts: [],
      techniques: opts.origin === "royal" ? ["Coil Court Step"] : ["Breath of Mud"],
      inventory: [],
      height: 50,
      body: 50,
    },
    world: {
      totalHours: 6,
      lastSimHour: 6,
      era: "Age of Kingdoms",
      history: ["Year 614. The Pale Coil still holds the valley."],
      rumors: [{ text: "Ashroot's well steamed green last night.", true: true, age: 0 }],
      npcs: [...named, ...extraNpcs()],
      graves: [],
      armies: [
        { id: "coil1", name: "Coil Banners", side: "coil", size: 1200, morale: 70, supplies: 80, loc: "iron_fort", general: "Shen" },
        { id: "salt1", name: "Salt Crown Fleet-Guard", side: "salt", size: 900, morale: 65, supplies: 90, loc: "salt_port", general: "Saffron" },
      ],
      fronts: [
        { id: "iron", name: "Iron Fort", control: "coil", siege: 0, kind: "fort" },
        { id: "road", name: "Pale Coil Road", control: "coil", siege: 0, kind: "pass" },
        { id: "port", name: "Salt Crown", control: "salt", siege: 0, kind: "city" },
        { id: "fen", name: "Greenfen", control: "coil", siege: 0, kind: "village" },
        { id: "ash", name: "Ashroot", control: "coil", siege: 0, kind: "village" },
      ],
      treaties: ["Uneasy salt-for-grain pact"],
      buildings: [{ id: "well", name: "Village Well", level: 1 }],
      activities: [],
      journey: null,
      sectGold: 400,
      sectPolitics: { loyalist: 40, reform: 25, ambition: 20, shadow: 15 },
      heavenLaw: 60,
      prices: 1,
      war: false,
    },
    kingdom: { gold: opts.origin === "royal" ? 12000 : 8000, tax: 8, legitimacy: opts.origin === "royal" ? 55 : 40 },
    settings: { timeSpeed: 1, showPower: true },
    combat: null,
    log: ["The well remembers your face."],
    confirmSkip: null,
    dream: null,
    inner: null,
  };
  refreshBoard(s);
  return s;
}

export function addHours(s: GameState, h: number) {
  s.world.totalHours += h;
  const days = h / 24;
  s.player.age += days / 360;
  if (s.player.age > s.player.lifespan) {
    fx(s, "Your lifespan ended. The soul refused the grave — for now.");
    imprint(s, "Survived death");
    s.player.age = s.player.lifespan - 1;
    s.player.karma -= 20;
  }
}

export function spendHours(s: GameState, h: number) {
  addHours(s, h);
  simWorld(s, h);
}

function scheduleAt(hour: number) {
  const t = hour % 24;
  if (t < 6) return "sleep";
  if (t < 8) return "eat";
  if (t < 16) return "work";
  if (t < 19) return "cultivate";
  if (t < 22) return "market";
  return "sleep";
}

function simWorld(s: GameState, hours: number) {
  const steps = Math.max(1, Math.floor(hours));
  for (let i = 0; i < Math.min(steps, 48); i++) {
    const hour = s.world.totalHours - hours + i + 1;
    for (const n of s.world.npcs) {
      if (!n.alive) continue;
      n.schedule = scheduleAt(hour);
      if (i === 0 && hours >= 24) {
        n.age += hours / 24 / 360;
        if (n.job !== "king" && Math.random() < 0.02) n.wealth += Math.floor((Math.random() - 0.3) * 20);
        if (n.rival) n.realm = Math.min(n.realm + (Math.random() < 0.15 ? 1 : 0), 10);
        if (n.nemesis && Math.random() < 0.08) {
          s.player.wanted += 2;
          fx(s, `${n.name} sent knives in the dark.`);
        }
        if (n.age > 90 + n.realm * 40 && Math.random() < 0.05) {
          n.alive = false;
          s.world.graves.unshift({ name: n.name, text: `${n.title}. Unfinished: ${n.goal}`, hour });
          fx(s, `${n.name} died. The field does not pause.`);
        }
      }
    }
  }
  s.world.rumors.forEach((r) => { r.age += hours / 24; });
  if (s.world.war) tickWar(s, hours);
  if (s.player.sect && hours >= 24) {
    s.world.sectGold += Math.floor(4 * hours / 24);
    const keys = Object.keys(s.world.sectPolitics);
    const k = keys[Math.floor(Math.random() * keys.length)]!;
    s.world.sectPolitics[k] = Math.max(5, Math.min(70, (s.world.sectPolitics[k] ?? 20) + (Math.random() < 0.5 ? 1 : -1)));
  }
  if (hours >= 24) {
    const cal = calendar(s.world.totalHours);
    if (cal.day === 1 && s.player.origin === "royal") {
      s.player.gold += 40;
      fx(s, "Royal stipend: 40 gold into your personal purse.");
    }
    s.kingdom.gold += Math.floor(s.kingdom.tax * 3 - 20);
    s.world.prices = Math.max(0.6, Math.min(1.8, s.world.prices + (Math.random() - 0.5) * 0.05));
  }
  if (Math.random() < hours / 200) {
    s.dream = {
      title: Math.random() < 0.5 ? "A true dream" : "A lying moon",
      text: Math.random() < 0.5
        ? "Kael of the Ashen Bell trains in a ruined bell-tower. He will find you in three seasons."
        : "The Coil-King drinks a cup that is already empty. The throne is yours if you take it tonight. (It is not.)",
      lie: Math.random() < 0.5,
    };
  }
  refreshBoard(s);
}

function tickWar(s: GameState, hours: number) {
  const days = hours / 24;
  for (const a of s.world.armies) {
    a.supplies = Math.max(0, a.supplies - days * 2);
    if (a.supplies < 10) a.morale = Math.max(10, a.morale - 3);
    a.size = Math.max(40, a.size - (a.supplies < 5 ? Math.floor(days * 8) : 0));
  }
  for (const f of s.world.fronts) {
    if (f.siege > 0) {
      f.siege += days * 4;
      if (f.siege >= 100) {
        f.control = f.control === "coil" ? "salt" : "coil";
        f.siege = 0;
        s.world.prices *= 1.1;
        fx(s, `${f.name} fell. The map redrew itself. Prices climbed.`);
        consequence(s, `front:${f.id}`);
      }
    }
  }
}

export function consequence(s: GameState, kind: string) {
  if (kind.startsWith("kill:")) {
    const id = kind.slice(5);
    const n = s.world.npcs.find((x) => x.id === id);
    if (!n) return;
    n.alive = false;
    s.world.graves.unshift({ name: n.name, text: `Cut down by ${s.player.name}.`, hour: s.world.totalHours });
    s.player.karma -= 12;
    s.player.wanted += 8;
    rumor(s, `${s.player.name} killed ${n.name}.`, true);
    s.player.legend[n.place] = "Murderer";
    if (n.id === "shen") {
      s.kingdom.legitimacy -= 25;
      s.world.war = true;
      s.world.era = "Age of Succession";
      fx(s, "The king is dead. The Pale Coil splits. War walks the road.");
      imprint(s, "Slew a king");
    }
    const kin = s.world.npcs.find((x) => x.alive && x.faction === n.faction && x.id !== n.id);
    if (kin) {
      kin.nemesis = true;
      kin.relation -= 40;
      fx(s, `${kin.name} will not forget.`);
    }
  } else if (kind === "tax") {
    s.world.prices *= 1.08;
    s.kingdom.gold += 400;
    s.kingdom.legitimacy -= 4;
    fx(s, "Taxes rise. Merchants raise prices. Villagers start walking.");
  } else if (kind.startsWith("front:")) {
    s.kingdom.legitimacy -= 3;
    rumor(s, "The war map changed overnight.", true);
  }
}

export function imprint(s: GameState, t: string) {
  if (!s.player.soul.includes(t)) s.player.soul.push(t);
}

export function refreshBoard(s: GameState) {
  const here = s.player.place;
  const pool: Activity[] = [
    { id: uid(), title: "Listen at the well", where: here, hours: 1, gold: 0, qi: 4, text: "Gossip is a cultivation resource.", kind: "talk" },
    { id: uid(), title: "Work a shift", where: here, hours: 4, gold: Math.floor(10 * s.world.prices), qi: 0, text: "Hands before heaven.", kind: "work" },
    { id: uid(), title: "Meditate on the road dust", where: here, hours: 3, gold: 0, qi: 18, text: "The Dao hides in ordinary dirt.", kind: "dao" },
    { id: uid(), title: "Hunt a rumor", where: here, hours: 2, gold: 0, qi: 0, text: "News has legs. Catch it.", kind: "rumor" },
    { id: uid(), title: "Spar whoever looks proud", where: here, hours: 2, gold: 0, qi: 8, text: "Pride is a training dummy.", kind: "spar" },
  ];
  const job = JOBS.find((j) => j.place === here);
  if (job) pool.unshift({ id: uid(), title: job.name, where: here, hours: job.hours, gold: Math.floor(job.gold * s.world.prices), qi: 2, text: "Honest work. The ledger notices.", kind: "job" });
  s.world.activities = pool.slice(0, 6);
}

export function doActivity(s: GameState, id: string) {
  const a = s.world.activities.find((x) => x.id === id);
  if (!a) return;
  spendHours(s, a.hours);
  s.player.gold += a.gold;
  s.player.qi += a.qi;
  fx(s, `${a.title}. +${a.gold}g +${a.qi} qi (${a.hours}h)`);
  if (a.kind === "dao" && Math.random() < 0.35) {
    s.player.qi += 20;
    imprint(s, "Dao from dust");
    fx(s, "A genuine insight. The Dao is not a button.");
  }
  if (a.kind === "spar") startCombat(s, nearby(s)[0]?.name ?? "Proud stranger");
  if (a.kind === "rumor" && s.world.rumors[0]) fx(s, "Heard: " + s.world.rumors[0].text);
}

export function nearby(s: GameState) {
  return s.world.npcs.filter((n) => n.alive && n.place === s.player.place);
}

export function talkTo(s: GameState, id: string, kind: "kind" | "gift" | "insult" | "recruit" | "scheme") {
  const n = s.world.npcs.find((x) => x.id === id);
  if (!n) return;
  spendHours(s, 1);
  n.memory.push(`${kind} @${Math.floor(s.world.totalHours)}`);
  n.memory = n.memory.slice(-8);
  if (kind === "kind") { n.relation += 8; n.loyalty += 3; fx(s, `${n.name} remembers the courtesy.`); }
  if (kind === "gift") {
    if (s.player.gold < 20) { fx(s, "Empty purse. They noticed."); n.relation -= 2; return; }
    s.player.gold -= 20; n.wealth += 20; n.relation += 14; fx(s, `A gift. ${n.name} weighs it.`);
  }
  if (kind === "insult") {
    n.relation -= 15; n.rival = true; fx(s, `${n.name} files you under enemy.`);
    if (n.relation < -30) n.nemesis = true;
  }
  if (kind === "recruit") {
    if (n.relation < 20) { fx(s, "They laugh. Not yet."); return; }
    if (!s.player.disciples.includes(n.id)) s.player.disciples.push(n.id);
    n.loyalty += 10;
    fx(s, `${n.name} bows — for now.`);
  }
  if (kind === "scheme") {
    s.world.sectPolitics[n.faction] = (s.world.sectPolitics[n.faction] ?? 10) + 4;
    n.relation += 5;
    fx(s, `A quiet word with ${n.name}. ${n.faction} gains a vote.`);
  }
}

export function beginTravel(s: GameState, to: PlaceId) {
  const dest = PLACE[to];
  if (!dest) return;
  if (s.player.realm < dest.reqRealm) { fx(s, `Realm too low. Need ${realmLabel(dest.reqRealm)}.`); return; }
  const from = PLACE[s.player.place];
  const hours = dest.hours || 4;
  const gold = dest.gold;
  if (s.player.gold < gold) { fx(s, "Not enough gold for the road."); return; }
  s.player.gold -= gold;
  s.world.journey = { from: s.player.place, to, left: hours, total: hours, method: hours > 12 ? "cloud-boat" : "walk" };
  fx(s, `Departing ${from?.name ?? "here"} → ${dest.name}. ${hours}h, ${gold}g.`);
  s.screen = "world";
}

export function pressOn(s: GameState) {
  const j = s.world.journey;
  if (!j) return;
  const step = Math.min(j.left, 6);
  spendHours(s, step);
  j.left -= step;
  if (Math.random() < 0.22) {
    const ev = ["Bandits on the ridge.", "A funeral procession blocks the road.", "You share tea with a nameless immortal.", "Rain. The Dao of water lectures you whether you asked."][Math.floor(Math.random() * 4)]!;
    fx(s, ev);
    s.player.qi += 6;
  }
  if (j.left <= 0) {
    s.player.place = j.to;
    s.world.journey = null;
    fx(s, `Arrived: ${PLACE[j.to]?.name}.`);
    refreshBoard(s);
  }
}

export function cultivate(s: GameState, hours: number) {
  spendHours(s, hours);
  const gain = Math.floor(hours * (3 + s.player.realm) * FOUNDATION_MUL[s.player.foundation]);
  s.player.qi += gain;
  fx(s, `Seclusion ${hours}h. +${gain} qi.`);
}

export function tryBreak(s: GameState) {
  const need = qiNeed(s.player.realm, s.player.stage);
  if (s.player.qi < need) { fx(s, `Need ${need} qi.`); return; }
  s.player.qi -= need;
  spendHours(s, 8);
  const roll = Math.random();
  const q = roll > 0.92 ? "transcendent" : roll > 0.7 ? "strong" : roll > 0.35 ? "steady" : "weak";
  s.player.lastBreak = q;
  if (s.player.stage >= 10) {
    s.player.realm += 1;
    s.player.stage = 1;
    s.player.lifespan = lifespanOf(s.player.realm, s.player.foundation);
    imprint(s, `Broke into ${realmLabel(s.player.realm)}`);
    fx(s, `MAJOR BREAKTHROUGH (${q}). ${realmLabel(s.player.realm, 1)}.`);
  } else {
    s.player.stage += 1;
    fx(s, `Stage breakthrough (${q}). ${realmLabel(s.player.realm, s.player.stage)}.`);
  }
}

export function startCombat(s: GameState, foe: string, npc?: Npc) {
  const php = 40 + s.player.realm * 18;
  const mhp = npc ? 30 + npc.realm * 16 : 28 + s.player.realm * 12;
  s.combat = { foe, hp: mhp, mhp, php, pmhp: php, log: [`${foe} draws.`], reward: 8 + (npc?.realm ?? 1) * 6 };
  s.screen = "combat";
}

export function combatHit(s: GameState, style: "strike" | "technique" | "flee") {
  const c = s.combat;
  if (!c) return;
  if (style === "flee") {
    spendHours(s, 1);
    s.combat = null;
    s.screen = "home";
    fx(s, "You left blood on the stones and kept your name.");
    return;
  }
  const atk = powerOf(s) * (style === "technique" ? 1.4 : 1);
  const dmg = Math.max(4, Math.floor(atk * (0.6 + Math.random() * 0.6) / 8));
  c.hp -= dmg;
  c.log.push(`You deal ${dmg}.`);
  if (c.hp <= 0) {
    s.player.gold += c.reward;
    s.player.qi += 10;
    imprint(s, `Beat ${c.foe}`);
    fx(s, `Victory over ${c.foe}. +${c.reward}g.`);
    const n = s.world.npcs.find((x) => x.name === c.foe);
    if (n) { n.rival = true; n.relation -= 10; }
    s.combat = null;
    s.screen = "home";
    return;
  }
  const back = Math.max(3, Math.floor((c.mhp / 10) * (0.5 + Math.random())));
  c.php -= back;
  c.log.push(`${c.foe} hits ${back}.`);
  if (c.php <= 0) {
    s.player.gold = Math.max(0, s.player.gold - 15);
    s.player.qi = Math.floor(s.player.qi * 0.8);
    imprint(s, "Tasted defeat");
    fx(s, `Defeat. ${c.foe} lets you crawl away.`);
    s.combat = null;
    s.screen = "home";
  }
}

export function joinSect(s: GameState, id: string) {
  const sect = SECTS.find((x) => x.id === id);
  if (!sect) return;
  s.player.sect = id;
  s.player.rank = "outer";
  spendHours(s, 4);
  fx(s, `Joined ${sect.name} as Outer Disciple.`);
  rumor(s, `${displayName(s)} entered ${sect.name}.`, true);
}

export function sectWork(s: GameState, hall: string) {
  spendHours(s, 4);
  if (hall === "library") {
    if (Math.random() < 0.3) {
      const t = "Hidden " + (DAO.find((d) => d.id === s.player.dao)?.name ?? "Dao") + " fragment";
      if (!s.player.techniques.includes(t)) s.player.techniques.push(t);
      fx(s, `A manual that was not supposed to be on the shelf: ${t}.`);
    } else fx(s, "Dust, commentary, one useful breath method. +12 qi.");
    s.player.qi += 12;
  } else if (hall === "train") {
    s.player.qi += 16;
    fx(s, "Sparring. Someone will remember how you fight.");
    const kael = s.world.npcs.find((n) => n.id === "kael");
    if (kael && kael.alive) { kael.rival = true; kael.relation -= 2; }
  } else if (hall === "alchemy") {
    s.player.gold -= 8;
    s.player.qi += 22;
    s.player.inventory.push("Qi pill");
    fx(s, "A bitter pill. It works.");
  } else if (hall === "treasury") {
    fx(s, `Sect purse: ${s.world.sectGold}g. You mark a leak in the ambition faction.`);
    s.world.sectPolitics.ambition = Math.max(5, (s.world.sectPolitics.ambition ?? 10) - 3);
  } else if (hall === "mission") {
    s.player.gold += 22;
    s.player.qi += 8;
    fx(s, "Contract complete. The world is slightly more afraid of your sect.");
  } else if (hall === "elder") {
    const f = FACTIONS[Math.floor(Math.random() * 4)]!;
    s.world.sectPolitics[f] = (s.world.sectPolitics[f] ?? 10) + 5;
    fx(s, `Council. You lean ${f}.`);
  } else if (hall === "court") {
    s.player.karma += 2;
    fx(s, "You judged a disciple dispute. Someone hates you fairly.");
  } else if (hall === "warhall") {
    s.world.war = true;
    fx(s, "War hall maps come out. The kingdom will hear of this.");
  } else if (hall === "leader") {
    if (s.player.rank === "elder" || s.player.rank === "leader") {
      s.player.mandate += 5;
      fx(s, "The seat listens.");
    } else fx(s, "The guards do not know your name yet.");
  }
}

export function foundSect(s: GameState, name: string, doctrine: string) {
  if (s.player.realm < 4) { fx(s, "Realm 4 before you found a house."); return; }
  s.world.foundedSect = { name: name || "Unnamed Court", dao: s.player.dao, doctrine: doctrine || "Live." };
  s.player.sect = "founded";
  s.player.rank = "leader";
  spendHours(s, 24);
  s.world.era = "Age of Sect Wars";
  fx(s, `The ${s.world.foundedSect.name} opens its gates.`);
  rumor(s, `A new sect: ${s.world.foundedSect.name}.`, true);
}

export function displayName(s: GameState) {
  return s.player.identityHidden && s.player.alias ? s.player.alias : s.player.name;
}

export function march(s: GameState, frontId: string) {
  const f = s.world.fronts.find((x) => x.id === frontId);
  if (!f) return;
  s.world.war = true;
  spendHours(s, 10);
  f.siege += 20;
  const a = s.world.armies[0];
  if (a) { a.morale -= 4; a.supplies -= 8; }
  fx(s, `March on ${f.name}. Siege ${Math.min(100, f.siege)}%.`);
}

export function joinBattle(s: GameState, frontId: string) {
  const f = s.world.fronts.find((x) => x.id === frontId);
  if (!f) return;
  startCombat(s, `${f.name} champion`);
}

export function levy(s: GameState) {
  consequence(s, "tax");
  spendHours(s, 6);
}

export function skipYears(s: GameState, years: number) {
  const hours = years * HOURS_YEAR;
  spendHours(s, hours);
  s.player.qi += years * 8;
  fx(s, `${years} year${years > 1 ? "s" : ""} pass. The world did not wait.`);
  s.confirmSkip = null;
  if (years >= 10) {
    s.world.era = years >= 100 ? "Age of Immortals" : "Age of Sect Wars";
    rumor(s, `Historians skip to a new heading: ${s.world.era}.`, true);
  }
}

export function previewSkip(s: GameState, years: number) {
  s.confirmSkip = {
    years,
    preview: `${years}y: you age ${years}, NPCs live and die, wars resolve, prices drift, rumors rot. Confirm?`,
  };
}

export function setSpeed(s: GameState, sp: TimeSpeed) {
  s.settings.timeSpeed = sp;
}

export function tick(s: GameState, dtMs: number) {
  if (s.combat) return;
  const sp = s.settings.timeSpeed;
  if (!sp) return;
  const gameMsPerHour = MS_PER_GAME_DAY / 24;
  const add = (dtMs * sp) / gameMsPerHour;
  if (add <= 0) return;
  // accumulate via fractional store on lastSimHour decimal
  const next = s.world.lastSimHour + add;
  const whole = Math.floor(next) - Math.floor(s.world.lastSimHour);
  s.world.lastSimHour = next;
  if (whole > 0) {
    addHours(s, whole);
    if (s.world.journey) {
      s.world.journey.left = Math.max(0, s.world.journey.left - whole);
      if (s.world.journey.left <= 0) {
        s.player.place = s.world.journey.to;
        fx(s, `The road ended at ${PLACE[s.world.journey.to]?.name}.`);
        s.world.journey = null;
      }
    }
    simWorld(s, whole);
  }
}

export function blackBuy(s: GameState, item: string, cost: number) {
  if (s.player.gold < cost) { fx(s, "The stall keeper smiles with too many teeth. No gold."); return; }
  s.player.gold -= cost;
  s.player.wanted += 6;
  s.player.inventory.push(item);
  spendHours(s, 2);
  fx(s, `Bought ${item} under the vein. Heaven may already know.`);
}

export function awakenArtifact(s: GameState) {
  if (s.player.gold < 80) { fx(s, "The anvil wants 80 gold of respect."); return; }
  s.player.gold -= 80;
  spendHours(s, 8);
  const art = { id: uid(), name: ["Ashen Bell Shard", "Hour-Eater", "Coil-Silence"][s.player.artifacts.length % 3]!, mood: "testing you", loyalty: 30 };
  s.player.artifacts.push(art);
  fx(s, `${art.name} opens an eye. It does not bow.`);
}

export function digRuin(s: GameState) {
  spendHours(s, 6);
  s.player.qi += 10;
  if (Math.random() < 0.4) {
    s.player.inventory.push("Broken inscription");
    fx(s, "A language older than the Coil. You can almost read a warning.");
    imprint(s, "Touched a lost age");
  } else fx(s, "Dust. Bones. A child's toy that outlived a city.");
}

export function enterInner(s: GameState) {
  spendHours(s, 5);
  s.inner = { title: "Heart-Demon Court", step: 0, path: ["A door of your own face.", "Kael stands inside it.", "You may forgive, fight, or walk around."] };
  s.screen = "inner";
}

export function innerPick(s: GameState, i: number) {
  if (!s.inner) return;
  s.inner.step += 1;
  if (i === 0) { s.player.karma += 4; s.player.qi += 30; fx(s, "Forgiveness is a technique. +30 qi."); }
  else if (i === 1) { startCombat(s, "Heart-Demon Kael"); return; }
  else { imprint(s, "Walked around a demon"); fx(s, "Cowardice, or wisdom. The soul files both."); }
  s.inner = null;
  s.screen = "cultivate";
}

export function sandbox(s: GameState, cmd: string) {
  if (cmd === "heaven") { s.player.realm = Math.max(5, s.player.realm); s.player.place = "time_market"; fx(s, "Dropped into Hourglass Row."); }
  if (cmd === "divine") { s.player.realm = 8; s.player.place = "law_palace"; }
  if (cmd === "chaos") { s.player.realm = 10; s.player.place = "chaos_shore"; }
  if (cmd === "king") { s.player.origin = "royal"; s.player.mandate = 70; s.kingdom.legitimacy = 80; }
  if (cmd === "war") { s.world.war = true; }
  if (cmd === "break") { s.player.qi = qiNeed(s.player.realm, s.player.stage) + 10; tryBreak(s); }
  if (cmd === "age") { s.world.npcs.forEach((n) => { n.age += 10; }); }
  if (cmd === "rival") { const k = s.world.npcs.find((n) => n.id === "kael"); if (k) k.rival = true; }
  if (cmd === "nemesis") { const k = s.world.npcs.find((n) => n.id === "lady"); if (k) k.nemesis = true; }
  if (cmd === "gold") { s.player.gold += 500; s.kingdom.gold += 2000; }
  if (cmd === "year") skipYears(s, 1);
}

export function go(s: GameState, screen: ScreenId) {
  s.screen = screen;
}
