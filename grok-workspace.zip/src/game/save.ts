import type { GameState } from "./types";
import { SAVE_VERSION } from "./data";

const KEY = "path-of-the-immortal-v5";

export function loadGame(): GameState | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as GameState;
    if (!s || s.v !== SAVE_VERSION) return null;
    return s;
  } catch {
    return null;
  }
}

export function saveGame(s: GameState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* quota */
  }
}

export function wipeSave() {
  localStorage.removeItem(KEY);
}
