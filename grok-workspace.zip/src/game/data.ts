import type { DaoId, FoundationGrade, Place, PlaceId } from "./types";

export const SAVE_VERSION = 5;
export const EPOCH_YEAR = 614;
export const MS_PER_GAME_DAY = 4.8 * 3600 * 1000; // 4h48m real = 1 game day
export const HOURS_YEAR = 360 * 24;

export const FOUNDATION_MUL: Record<FoundationGrade, number> = {
  broken: 0.7,
  ordinary: 1,
  solid: 1.15,
  excellent: 1.35,
  heavenly: 1.7,
  primordial: 2.2,
};

export const REALM_NAME = [
  "Mortal Shell",
  "Qi Gathering",
  "Foundation",
  "Core Formation",
  "Nascent Soul",
  "Soul Transformation",
  "Void Refining",
  "Body Integration",
  "Mahayana",
  "Tribulation",
  "Immortal",
];

export function realmBand(r: number) {
  if (r <= 2) return "Early";
  if (r <= 5) return "Middle";
  if (r <= 8) return "Late";
  return "Peak";
}

export function realmLabel(r: number, stage = 1) {
  const n = REALM_NAME[Math.max(0, Math.min(10, r))] ?? "Unknown";
  const roman = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][stage] ?? "";
  return `${n} · ${realmBand(r)} ${roman}`.trim();
}

export const DAO: { id: DaoId; name: string; rival: DaoId; blurb: string }[] = [
  { id: "sword", name: "Sword", rival: "shadow", blurb: "Edge that remembers every cut." },
  { id: "fire", name: "Fire", rival: "water", blurb: "Hunger that eats heaven." },
  { id: "water", name: "Water", rival: "fire", blurb: "Patience that drowns empires." },
  { id: "life", name: "Life", rival: "death", blurb: "Green that refuses the grave." },
  { id: "death", name: "Death", rival: "life", blurb: "The last honest teacher." },
  { id: "order", name: "Order", rival: "chaos", blurb: "Law that binds even gods." },
  { id: "chaos", name: "Chaos", rival: "order", blurb: "The first dark, still hungry." },
  { id: "shadow", name: "Shadow", rival: "sword", blurb: "Names that never reach the ledger." },
  { id: "time", name: "Time", rival: "chaos", blurb: "Hours sold, years stolen." },
];

export const PLACES: Place[] = [
  { id: "ashroot", name: "Ashroot Village", layer: "mortal", kind: "village", art: "/art/ashroot.png", blurb: "Mud, well-water, and a mountain that pretends not to watch.", hours: 0, gold: 0, reqRealm: 0, adj: ["coil_road", "greenfen", "cinder"] },
  { id: "coil_road", name: "Pale Coil Road", layer: "mortal", kind: "road", art: "/art/coil-palace.png", blurb: "Banners of a dying house. Tolls first, justice later.", hours: 6, gold: 8, reqRealm: 0, adj: ["ashroot", "coil_palace", "salt_port"] },
  { id: "coil_palace", name: "Pale Coil Palace", layer: "mortal", kind: "capital", art: "/art/coil-palace.png", blurb: "Wet black stone. A throne that still remembers blood.", hours: 8, gold: 20, reqRealm: 0, adj: ["coil_road", "silent_blade", "iron_fort"] },
  { id: "salt_port", name: "Salt Crown Port", layer: "mortal", kind: "port", art: "/art/salt-port.png", blurb: "Two gods, one harbor. All tariffs bow.", hours: 10, gold: 18, reqRealm: 0, adj: ["coil_road", "jade_harbor", "heaven_gate"] },
  { id: "silent_blade", name: "Silent Blade Sect", layer: "mortal", kind: "sect", art: "/art/coil-palace.png", blurb: "Bells that remember every oath broken here.", hours: 8, gold: 12, reqRealm: 1, adj: ["coil_palace", "mist_temple"] },
  { id: "mist_temple", name: "Mist Temple", layer: "mortal", kind: "temple", art: "/art/ashroot.png", blurb: "Fog that edits memory if you stay the night.", hours: 7, gold: 6, reqRealm: 1, adj: ["silent_blade", "greenfen"] },
  { id: "greenfen", name: "Greenfen", layer: "mortal", kind: "farm", art: "/art/ashroot.png", blurb: "Rot and bloom share a ditch.", hours: 4, gold: 4, reqRealm: 0, adj: ["ashroot", "mist_temple"] },
  { id: "iron_fort", name: "Iron Fort", layer: "mortal", kind: "fort", art: "/art/coil-palace.png", blurb: "The kingdom's last honest wall.", hours: 9, gold: 10, reqRealm: 2, adj: ["coil_palace", "cinder"] },
  { id: "cinder", name: "Cinder Ruins", layer: "mortal", kind: "ruin", art: "/art/ashroot.png", blurb: "A city that chose fire over surrender.", hours: 8, gold: 5, reqRealm: 2, adj: ["ashroot", "iron_fort"] },
  { id: "jade_harbor", name: "Jade Harbor", layer: "mortal", kind: "market", art: "/art/salt-port.png", blurb: "Silk, poisons, and names for sale.", hours: 9, gold: 14, reqRealm: 1, adj: ["salt_port"] },
  // Heaven city
  { id: "heaven_gate", name: "Heaven Gate", layer: "heaven", kind: "gate", art: "/art/heaven-market.png", blurb: "Clouds underfoot. Your mortal name is already being rewritten.", hours: 16, gold: 40, reqRealm: 5, adj: ["salt_port", "court_square", "heaven_port"] },
  { id: "court_square", name: "Court of Measures", layer: "heaven", kind: "government", art: "/art/heaven-market.png", blurb: "Records. Judge. Allocate. Continue.", hours: 3, gold: 0, reqRealm: 5, adj: ["heaven_gate", "time_market", "noble_terrace", "law_prison"] },
  { id: "time_market", name: "Hourglass Row", layer: "heaven", kind: "market", art: "/art/heaven-market.png", blurb: "Buy. Borrow. Extend. Forget.", hours: 2, gold: 0, reqRealm: 5, adj: ["court_square", "craft_forge", "cloud_inn", "poor_mist"] },
  { id: "noble_terrace", name: "Noble Terrace", layer: "heaven", kind: "noble", art: "/art/heaven-market.png", blurb: "White stone, gold law, no mud allowed.", hours: 2, gold: 0, reqRealm: 6, adj: ["court_square", "sect_district", "cultivate_peak"] },
  { id: "poor_mist", name: "Mist Wards", layer: "heaven", kind: "slum", art: "/art/heaven-market.png", blurb: "Immortals who still owe rent.", hours: 2, gold: 0, reqRealm: 5, adj: ["time_market", "under_vein", "heal_hall"] },
  { id: "sect_district", name: "Nine Heaven Courts", layer: "heaven", kind: "sect", art: "/art/heaven-market.png", blurb: "Three heavenly sects share one sky and none of the credit.", hours: 3, gold: 0, reqRealm: 5, adj: ["noble_terrace", "cultivate_peak"] },
  { id: "cultivate_peak", name: "Still Cloud Peak", layer: "heaven", kind: "cultivate", art: "/art/heaven-market.png", blurb: "The air itself cultivates you — for a price in years.", hours: 3, gold: 0, reqRealm: 5, adj: ["noble_terrace", "sect_district"] },
  { id: "law_prison", name: "Unbroken Cells", layer: "heaven", kind: "prison", art: "/art/heaven-market.png", blurb: "What is taken is not lost. Only reassigned.", hours: 3, gold: 0, reqRealm: 5, adj: ["court_square"] },
  { id: "heal_hall", name: "White Bone Hall", layer: "heaven", kind: "heal", art: "/art/heaven-market.png", blurb: "They mend the body. They invoice the soul.", hours: 2, gold: 0, reqRealm: 5, adj: ["poor_mist", "cloud_inn"] },
  { id: "craft_forge", name: "Star Anvil", layer: "heaven", kind: "craft", art: "/art/heaven-market.png", blurb: "Artifacts argue while they are still being made.", hours: 2, gold: 0, reqRealm: 5, adj: ["time_market"] },
  { id: "cloud_inn", name: "Longer Tomorrow Inn", layer: "heaven", kind: "inn", art: "/art/heaven-market.png", blurb: "Hours, days, seasons, years — rooms by the century.", hours: 1, gold: 0, reqRealm: 5, adj: ["time_market", "heal_hall"] },
  { id: "heaven_port", name: "Cloud Pier", layer: "heaven", kind: "port", art: "/art/salt-port.png", blurb: "Ships that sail storm-law, not water.", hours: 3, gold: 0, reqRealm: 5, adj: ["heaven_gate"] },
  { id: "under_vein", name: "Under-Vein", layer: "heaven", kind: "secret", art: "/art/heaven-market.png", blurb: "Heaven's black market: forbidden manuals, fake names, true knives.", hours: 3, gold: 0, reqRealm: 5, adj: ["poor_mist"] },
  // Divine
  { id: "law_palace", name: "Palace of Unbroken Law", layer: "divine", kind: "city", art: "/art/heaven-market.png", blurb: "A civilization of verdicts. Breathing is a permit.", hours: 24, gold: 80, reqRealm: 8, adj: ["heaven_gate", "thunder_sea"] },
  { id: "thunder_sea", name: "Thunder Sea", layer: "divine", kind: "wild", art: "/art/salt-port.png", blurb: "Lightning with a census. Cities on the bolts.", hours: 20, gold: 60, reqRealm: 8, adj: ["law_palace", "immortal_peak"] },
  { id: "immortal_peak", name: "Nameless Peak", layer: "divine", kind: "cultivate", art: "/art/coil-palace.png", blurb: "Where immortals go to stop being people.", hours: 18, gold: 50, reqRealm: 9, adj: ["thunder_sea"] },
  // Primordial
  { id: "chaos_shore", name: "Chaos Shore", layer: "primordial", kind: "wild", art: "/art/key-art.png", blurb: "The world before names. It still wants them back.", hours: 40, gold: 120, reqRealm: 10, adj: ["immortal_peak", "unmade"] },
  { id: "unmade", name: "The Unmade City", layer: "primordial", kind: "ruin", art: "/art/key-art.png", blurb: "Architecture that remembers being a language.", hours: 30, gold: 90, reqRealm: 10, adj: ["chaos_shore", "first_dark"] },
  { id: "first_dark", name: "First Dark", layer: "primordial", kind: "secret", art: "/art/key-art.png", blurb: "Before light. Before law. Before you.", hours: 40, gold: 0, reqRealm: 10, adj: ["unmade"] },
];

export const PLACE = Object.fromEntries(PLACES.map((p) => [p.id, p])) as Record<PlaceId, Place>;

export const SECTS = [
  { id: "silent_blade", name: "Silent Blade", dao: "sword" as DaoId, place: "silent_blade", motto: "A blade remembers." },
  { id: "pale_coil", name: "House of the Pale Coil", dao: "order" as DaoId, place: "coil_palace", motto: "Silence wears gold." },
  { id: "nine_heaven", name: "Nine Heaven Court", dao: "order" as DaoId, place: "sect_district", motto: "Measure all things." },
  { id: "thunder_court", name: "Thunder Court", dao: "fire" as DaoId, place: "sect_district", motto: "Law is a storm with a ledger." },
  { id: "unbroken_law", name: "Unbroken Law", dao: "order" as DaoId, place: "law_palace", motto: "What is taken is reassigned." },
];

export const FACTIONS = ["loyalist", "reform", "ambition", "shadow", "merchant"];

export const HALLS = [
  { id: "library", name: "Scripture Library", act: "Browse manuals" },
  { id: "train", name: "Training Hall", act: "Spar a disciple" },
  { id: "alchemy", name: "Alchemy Hall", act: "Refine a pill" },
  { id: "treasury", name: "Treasury", act: "Audit the books" },
  { id: "mission", name: "Mission Hall", act: "Take a contract" },
  { id: "elder", name: "Elder Hall", act: "Sit the council" },
  { id: "court", name: "Disciples' Court", act: "Judge a dispute" },
  { id: "warhall", name: "War Hall", act: "Plan a strike" },
  { id: "leader", name: "Leader Residence", act: "Petition the seat" },
];

export const JOBS = [
  { id: "well", name: "Draw well-water", hours: 3, gold: 6, place: "ashroot" },
  { id: "hoe", name: "Hoe the fen", hours: 5, gold: 9, place: "greenfen" },
  { id: "toll", name: "Collect a road toll", hours: 4, gold: 14, place: "coil_road" },
  { id: "dock", name: "Unload salt barges", hours: 6, gold: 18, place: "salt_port" },
  { id: "hour", name: "Sell an hourglass", hours: 4, gold: 40, place: "time_market" },
  { id: "scribe", name: "Copy a verdict", hours: 5, gold: 32, place: "court_square" },
  { id: "inn", name: "Keep the inn", hours: 6, gold: 28, place: "cloud_inn" },
  { id: "forge", name: "Pump the star anvil", hours: 5, gold: 36, place: "craft_forge" },
];

export function portraitOf(gender: "male" | "female", origin: "commoner" | "royal") {
  if (gender === "female" && origin === "royal") return "/art/hero-female-royal.png";
  if (gender === "female") return "/art/hero-female-commoner.png";
  return "/art/hero-male-commoner.png";
}

export function qiNeed(realm: number, stage: number) {
  return Math.floor(40 * Math.pow(1.45, realm) * (0.6 + stage * 0.4));
}

export function lifespanOf(realm: number, foundation: FoundationGrade) {
  const base = [70, 90, 140, 220, 400, 700, 1200, 2000, 3500, 6000, 12000][Math.min(10, realm)] ?? 70;
  return Math.floor(base * FOUNDATION_MUL[foundation]);
}

export const NAMED_NPCS = [
  { id: "shen", name: "Coil-King Shen", title: "Throne of Fading Heavens", portrait: "/art/npc-shen.png", place: "coil_palace", job: "king", realm: 6, wealth: 90000, age: 71, gender: "male" as const, faction: "loyalist", goal: "Die crowned, not remembered as a footnote.", destiny: "Last king — or first immortal emperor", schedule: "Court at dawn, wine at dusk, war in between.", },
  { id: "lady", name: "Lady of the Pale Coil", title: "Silence Wears Gold", portrait: "/art/npc-lady.png", place: "coil_palace", job: "princess", realm: 4, wealth: 18000, age: 24, gender: "female" as const, faction: "ambition", goal: "A throne that does not need a husband.", destiny: "Future empress — if she is not first a traitor", schedule: "Dawn sword, noon ledgers, midnight letters.", },
  { id: "wren", name: "Wren of Greenfen", title: "Bloom in the Rot", portrait: "/art/npc-wren.png", place: "greenfen", job: "herbalist", realm: 2, wealth: 40, age: 19, gender: "female" as const, faction: "reform", goal: "Keep one field alive through the next famine.", destiny: "Saint of the lower world", schedule: "Dawn herbs, noon clinic, dusk at the well.", },
  { id: "saffron", name: "Saffron of the Dust Road", title: "All Things Have a Price", portrait: "/art/npc-saffron.png", place: "salt_port", job: "merchant", realm: 3, wealth: 4200, age: 27, gender: "male" as const, faction: "merchant", goal: "Own the harbor the gods tax.", destiny: "King of a market, never a throne", schedule: "Docks at first light, auction at dusk.", },
  { id: "kael", name: "Kael of the Ashen Bell", title: "A Blade Remembers", portrait: "/art/npc-kael.png", place: "silent_blade", job: "inner disciple", realm: 3, wealth: 220, age: 22, gender: "male" as const, faction: "ambition", goal: "Surpass whoever last beat him.", destiny: "Rival — or the next sect leader", schedule: "Spar until the bell, meditate until it cracks.", },
  { id: "farmer", name: "Old Farmer of Ashroot", title: "Some Choose the Field", portrait: "/art/npc-farmer.png", place: "ashroot", job: "farmer", realm: 0, wealth: 12, age: 67, gender: "male" as const, faction: "loyalist", goal: "See one more harvest.", destiny: "Witness. The world keeps him to remember mud.", schedule: "Hoe at cockcrow, well at noon, sleep with the hens.", },
];

export const SANDBOX_CODE = "immortal";
