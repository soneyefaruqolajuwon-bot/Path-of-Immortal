export type ScreenId =
  | "title"
  | "create"
  | "home"
  | "character"
  | "cultivate"
  | "world"
  | "heaven"
  | "divine"
  | "primordial"
  | "sect"
  | "kingdom"
  | "war"
  | "people"
  | "market"
  | "black"
  | "society"
  | "dream"
  | "inner"
  | "ruins"
  | "companion"
  | "artifact"
  | "rumor"
  | "identity"
  | "combat"
  | "sandbox"
  | "more";

export type TimeSpeed = 0 | 1 | 2 | 5;
export type Gender = "male" | "female";
export type Origin = "commoner" | "royal";
export type FoundationGrade =
  | "broken"
  | "ordinary"
  | "solid"
  | "excellent"
  | "heavenly"
  | "primordial";
export type SectRank =
  | "none"
  | "outer"
  | "inner"
  | "core"
  | "elder"
  | "leader";
export type DaoId =
  | "sword"
  | "fire"
  | "water"
  | "life"
  | "death"
  | "order"
  | "chaos"
  | "shadow"
  | "time";

export type PlaceId = string;

export type Npc = {
  id: string;
  name: string;
  title: string;
  portrait: string;
  place: PlaceId;
  job: string;
  realm: number;
  wealth: number;
  age: number;
  gender: Gender;
  faction: string;
  goal: string;
  destiny: string;
  loyalty: number;
  memory: string[];
  alive: true | false;
  schedule: string;
  relation: number;
  rival?: boolean;
  nemesis?: boolean;
};

export type Place = {
  id: PlaceId;
  name: string;
  layer: "mortal" | "heaven" | "divine" | "primordial";
  kind: string;
  art: string;
  blurb: string;
  hours: number;
  gold: number;
  reqRealm: number;
  adj: PlaceId[];
};

export type Army = {
  id: string;
  name: string;
  side: "coil" | "salt" | "player" | "rebel";
  size: number;
  morale: number;
  supplies: number;
  loc: PlaceId;
  general: string;
};

export type Front = {
  id: string;
  name: string;
  control: Army["side"];
  siege: number;
  kind: "city" | "fort" | "village" | "pass";
};

export type Activity = {
  id: string;
  title: string;
  where: PlaceId;
  hours: number;
  gold: number;
  qi: number;
  text: string;
  kind: string;
};

export type Journey = {
  from: PlaceId;
  to: PlaceId;
  left: number;
  total: number;
  method: string;
};

export type CombatState = {
  foe: string;
  hp: number;
  mhp: number;
  php: number;
  pmhp: number;
  log: string[];
  reward: number;
};

export type GameState = {
  v: number;
  screen: ScreenId;
  player: {
    name: string;
    gender: Gender;
    origin: Origin;
    dao: DaoId;
    realm: number;
    stage: number;
    qi: number;
    foundation: FoundationGrade;
    lastBreak: string;
    gold: number;
    age: number;
    lifespan: number;
    karma: number;
    place: PlaceId;
    sect: string;
    rank: SectRank;
    wanted: number;
    alias: string;
    identityHidden: boolean;
    soul: string[];
    legend: Record<string, string>;
    mandate: number;
    disciples: string[];
    master: string;
    companion: string;
    artifacts: { id: string; name: string; mood: string; loyalty: number }[];
    techniques: string[];
    inventory: string[];
    height: number;
    body: number;
  };
  world: {
    totalHours: number;
    lastSimHour: number;
    era: string;
    history: string[];
    rumors: { text: string; true: boolean; age: number }[];
    npcs: Npc[];
    graves: { name: string; text: string; hour: number }[];
    armies: Army[];
    fronts: Front[];
    treaties: string[];
    buildings: { id: string; name: string; level: number }[];
    activities: Activity[];
    journey: Journey | null;
    sectGold: number;
    sectPolitics: Record<string, number>;
    heavenLaw: number;
    prices: number;
    war: boolean;
    foundedSect?: { name: string; dao: DaoId; doctrine: string };
  };
  kingdom: { gold: number; tax: number; legitimacy: number };
  settings: { timeSpeed: TimeSpeed; showPower: boolean };
  combat: CombatState | null;
  log: string[];
  confirmSkip: null | { years: number; preview: string };
  dream: null | { title: string; text: string; lie: boolean };
  inner: null | { title: string; step: number; path: string[] };
};
