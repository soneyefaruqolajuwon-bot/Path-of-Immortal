import { useEffect, useState, type ReactNode } from "react";
import {
  Home, Map, Landmark, Crown, Cloud, Menu, Pause, Play, Swords, ScrollText, Users,
} from "lucide-react";
import { useGame } from "@/game/store";
import { calendar, displayName, nearby, powerOf } from "@/game/engine";
import { DAO, HALLS, PLACE, PLACES, SECTS, portraitOf, qiNeed, realmLabel } from "@/game/data";
import type { DaoId, Gender, Origin, ScreenId } from "@/game/types";

const NAV: { id: ScreenId; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Board", icon: Home },
  { id: "world", label: "World", icon: Map },
  { id: "sect", label: "Sect", icon: Landmark },
  { id: "kingdom", label: "War", icon: Crown },
  { id: "heaven", label: "Heaven", icon: Cloud },
  { id: "more", label: "More", icon: Menu },
];

export function GameApp() {
  const boot = useGame((g) => g.boot);
  const s = useGame((g) => g.s);
  const tick = useGame((g) => g.tick);
  const [creating, setCreating] = useState(false);
  useEffect(() => { boot(); }, [boot]);
  useEffect(() => {
    let last = performance.now();
    let raf = 0;
    const loop = (now: number) => {
      const dt = Math.min(120, now - last);
      last = now;
      tick(dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [tick]);
  if (creating) return <Create onDone={() => setCreating(false)} />;
  if (!s) return <Title onBegin={() => setCreating(true)} />;
  return <Shell />;
}

function Title({ onBegin }: { onBegin: () => void }) {
  const s = useGame((g) => g.s);
  const go = useGame((g) => g.go);
  return (
    <div className="relative min-h-dvh overflow-hidden bg-ink">
      <img src="/art/key-art.png" alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="scrim absolute inset-0" />
      <div className="relative z-10 flex min-h-dvh flex-col justify-end px-5 pb-10 pt-16">
        <p className="font-display text-xs tracking-[0.35em] text-gold">PATH OF THE IMMORTAL</p>
        <h1 className="mt-2 max-w-sm font-display text-4xl leading-tight text-gold-soft">
          One life. A world that does not wait.
        </h1>
        <p className="mt-3 max-w-md text-sm text-bone/80">
          Cultivate, scheme, march, and live in Heaven. The calendar is slow. The consequences are not.
        </p>
        <div className="mt-6 flex flex-col gap-2">
          <button className="min-h-12 rounded-lg bg-gold px-4 font-display text-ink" onClick={onBegin}>
            Begin a life
          </button>
          {s ? (
            <button className="min-h-12 rounded-lg border border-gold/40 px-4 text-gold-soft" onClick={() => go("home")}>
              Continue
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function Create({ onDone }: { onDone: () => void }) {
  const create = useGame((g) => g.create);
  const [name, setName] = useState("");
  const [gender, setGender] = useState<Gender>("male");
  const [origin, setOrigin] = useState<Origin>("commoner");
  const [dao, setDao] = useState<DaoId>("sword");
  const art = portraitOf(gender, origin);
  return (
    <div className="min-h-dvh bg-ink px-4 py-6">
      <p className="font-display text-xs tracking-[0.3em] text-gold">NEW LIFE</p>
      <h2 className="mt-1 font-display text-2xl text-gold-soft">Who walks the mud?</h2>
      <img src={art} alt="" className="mt-4 h-64 w-full rounded-xl object-cover object-top" />
      <label className="mt-4 block text-xs text-muted">Name</label>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Unnamed"
        className="mt-1 min-h-12 w-full rounded-lg border border-line bg-paper px-3 text-bone"
      />
      <div className="mt-3 grid grid-cols-2 gap-2">
        {(["male", "female"] as const).map((g) => (
          <Chip key={g} on={gender === g} onClick={() => setGender(g)}>{g}</Chip>
        ))}
        {(["commoner", "royal"] as const).map((o) => (
          <Chip key={o} on={origin === o} onClick={() => setOrigin(o)}>{o}</Chip>
        ))}
      </div>
      <p className="mt-4 text-xs text-muted">Dao</p>
      <div className="mt-1 flex flex-wrap gap-2">
        {DAO.map((d) => (
          <Chip key={d.id} on={dao === d.id} onClick={() => setDao(d.id)}>{d.name}</Chip>
        ))}
      </div>
      <button
        className="mt-6 min-h-12 w-full rounded-lg bg-gold font-display text-ink"
        onClick={() => { create({ name, gender, origin, dao }); onDone(); }}
      >
        Step into the year 614
      </button>
    </div>
  );
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`min-h-11 rounded-lg border px-3 text-sm capitalize ${on ? "border-gold bg-gold/15 text-gold-soft" : "border-line text-muted"}`}
    >
      {children}
    </button>
  );
}

function Shell() {
  const s = useGame((g) => g.s)!;
  const go = useGame((g) => g.go);
  const speed = useGame((g) => g.speed);
  const press = useGame((g) => g.press);
  const loc = PLACE[s.player.place];
  const cal = calendar(s.world.totalHours);
  const art = loc?.art ?? "/art/key-art.png";
  return (
    <div className="relative mx-auto flex min-h-dvh max-w-lg flex-col bg-ink">
      <div className="relative h-36 shrink-0 overflow-hidden">
        <img src={art} alt="" className="h-full w-full object-cover" />
        <div className="scrim absolute inset-0" />
        <div className="absolute inset-x-0 bottom-0 p-3">
          <p className="font-display text-xs tracking-widest text-gold">{loc?.name}</p>
          <p className="text-[11px] text-bone/80">
            Y{cal.year}.{String(cal.month).padStart(2, "0")}.{String(cal.day).padStart(2, "0")} · {String(cal.hour).padStart(2, "0")}:00 · {s.world.era}
          </p>
        </div>
      </div>
      <header className="flex items-center justify-between gap-2 border-b border-line px-3 py-2 text-xs">
        <button className="text-left" onClick={() => go("character")}>
          <span className="font-display text-gold-soft">{displayName(s)}</span>
          <span className="ml-2 text-muted">{realmLabel(s.player.realm, s.player.stage)}</span>
        </button>
        <div className="flex items-center gap-2 text-gold">
          <span>{s.player.gold}g</span>
          <span className="text-muted">crown {s.kingdom.gold}g</span>
        </div>
      </header>
      <div className="flex gap-1 border-b border-line px-2 py-1">
        {([0, 1, 2, 5] as const).map((sp) => (
          <button
            key={sp}
            onClick={() => speed(sp)}
            className={`flex min-h-10 min-w-10 items-center justify-center rounded-md text-xs ${s.settings.timeSpeed === sp ? "bg-gold text-ink" : "text-muted"}`}
          >
            {sp === 0 ? <Pause className="size-3.5" /> : sp === 1 ? <Play className="size-3.5" /> : `${sp}×`}
          </button>
        ))}
        {s.world.journey ? (
          <button onClick={press} className="ml-auto min-h-10 rounded-md bg-gold/20 px-3 text-xs text-gold-soft">
            Press on · {s.world.journey.left}h
          </button>
        ) : null}
      </div>
      <main className="min-h-0 flex-1 overflow-y-auto px-3 py-3 pb-28">
        <Screen />
      </main>
      {s.confirmSkip ? <SkipModal /> : null}
      <nav className="fixed inset-x-0 bottom-0 z-20 mx-auto flex max-w-lg border-t border-line bg-ink/95">
        {NAV.map((n) => {
          const Icon = n.icon;
          const on = s.screen === n.id || (n.id === "kingdom" && s.screen === "war");
          return (
            <button key={n.id} onClick={() => go(n.id)} className={`flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-[10px] ${on ? "text-gold" : "text-muted"}`}>
              <Icon className="size-4" />
              {n.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}

function Screen() {
  const s = useGame((g) => g.s)!;
  switch (s.screen) {
    case "home": return <HomeBoard />;
    case "character": return <Character />;
    case "cultivate": return <Cultivate />;
    case "world": return <World />;
    case "heaven": return <Heaven />;
    case "divine": return <Layer layer="divine" />;
    case "primordial": return <Layer layer="primordial" />;
    case "sect": return <Sect />;
    case "kingdom":
    case "war": return <War />;
    case "people": return <People />;
    case "market": return <Market />;
    case "black": return <Black />;
    case "society": return <Society />;
    case "dream": return <Dream />;
    case "inner": return <Inner />;
    case "ruins": return <Ruins />;
    case "companion": return <Companions />;
    case "artifact": return <Artifacts />;
    case "rumor": return <Rumors />;
    case "identity": return <Identity />;
    case "combat": return <Combat />;
    case "sandbox": return <Sandbox />;
    default: return <More />;
  }
}

function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`mb-3 rounded-xl border border-line bg-paper p-3 ${className}`}>{children}</section>;
}

function HomeBoard() {
  const s = useGame((g) => g.s)!;
  const act = useGame((g) => g.act);
  const go = useGame((g) => g.go);
  return (
    <>
      <p className="mb-2 text-xs text-muted">{PLACE[s.player.place]?.blurb}</p>
      <Card>
        <p className="font-display text-sm text-gold">What you can do</p>
        <ul className="mt-2 space-y-2">
          {s.world.activities.map((a) => (
            <li key={a.id}>
              <button onClick={() => act(a.id)} className="flex min-h-12 w-full items-center justify-between rounded-lg border border-line px-3 text-left">
                <span>
                  <span className="block text-sm text-bone">{a.title}</span>
                  <span className="text-[11px] text-muted">{a.hours}h · {a.gold}g · {a.qi} qi</span>
                </span>
                <span className="text-gold text-xs">Do</span>
              </button>
            </li>
          ))}
        </ul>
      </Card>
      <div className="grid grid-cols-2 gap-2">
        <Quick onClick={() => go("cultivate")} icon={<ScrollText className="size-4" />} label="Cultivate" />
        <Quick onClick={() => go("people")} icon={<Users className="size-4" />} label="People here" />
        <Quick onClick={() => go("character")} icon={<Swords className="size-4" />} label="Identity" />
        <Quick onClick={() => go("rumor")} icon={<Cloud className="size-4" />} label="Rumors" />
      </div>
      <Log />
    </>
  );
}

function Quick({ onClick, icon, label }: { onClick: () => void; icon: ReactNode; label: string }) {
  return (
    <button onClick={onClick} className="flex min-h-12 items-center gap-2 rounded-xl border border-line bg-paper px-3 text-sm text-bone">
      <span className="text-gold">{icon}</span>{label}
    </button>
  );
}

function Log() {
  const s = useGame((g) => g.s)!;
  return (
    <Card>
      <p className="font-display text-sm text-gold">Chronicle</p>
      <ul className="mt-2 space-y-1 text-xs text-muted">
        {s.log.slice(0, 8).map((l, i) => <li key={i}>{l}</li>)}
      </ul>
    </Card>
  );
}

function Character() {
  const s = useGame((g) => g.s)!;
  const art = portraitOf(s.player.gender, s.player.origin);
  return (
    <>
      <img src={art} alt="" className="mb-3 h-72 w-full rounded-xl object-cover object-top" />
      <Card>
        <p className="font-display text-lg text-gold-soft">{displayName(s)}</p>
        <p className="text-xs text-muted">{realmLabel(s.player.realm, s.player.stage)} · {s.player.foundation} foundation</p>
        <p className="mt-2 text-sm">Age {s.player.age.toFixed(1)} / {s.player.lifespan} · Power {powerOf(s)}</p>
        <p className="text-sm">Dao {s.player.dao} · Karma {s.player.karma} · Mandate {s.player.mandate}</p>
        <p className="mt-2 text-xs text-muted">Soul imprints: {s.player.soul.join(" · ") || "none yet"}</p>
        <p className="mt-1 text-xs text-muted">Techniques: {s.player.techniques.join(", ")}</p>
        <p className="mt-1 text-xs text-gold">Legend here: {s.player.legend[s.player.place] ?? "Unknown wanderer"}</p>
      </Card>
    </>
  );
}

function Cultivate() {
  const s = useGame((g) => g.s)!;
  const cult = useGame((g) => g.cult);
  const brk = useGame((g) => g.brk);
  const inner = useGame((g) => g.inner);
  const ask = useGame((g) => g.askSkip);
  const need = qiNeed(s.player.realm, s.player.stage);
  return (
    <>
      <Card>
        <p className="font-display text-sm text-gold">Foundation · {s.player.foundation}</p>
        <p className="text-xs text-muted">Last break: {s.player.lastBreak}. Realm is not total power.</p>
        <p className="mt-2 text-sm">{s.player.qi} / {need} qi</p>
        <div className="mt-2 h-2 overflow-hidden rounded bg-ink">
          <div className="h-full bg-gold" style={{ width: `${Math.min(100, (s.player.qi / need) * 100)}%` }} />
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {[7, 30, 90].map((h) => (
            <button key={h} onClick={() => cult(h * 24)} className="min-h-12 rounded-lg border border-line text-xs">Seclude {h}d</button>
          ))}
        </div>
        <button onClick={brk} className="mt-2 min-h-12 w-full rounded-lg bg-gold font-display text-ink">Attempt breakthrough</button>
        <button onClick={inner} className="mt-2 min-h-12 w-full rounded-lg border border-gold/40 text-gold">Enter meditation</button>
      </Card>
      <Card>
        <p className="font-display text-sm text-gold">Skip time</p>
        <p className="text-xs text-muted">Requires confirmation. The world keeps living.</p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {[1, 10, 100].map((y) => (
            <button key={y} onClick={() => ask(y)} className="min-h-12 rounded-lg border border-line text-xs">{y} year</button>
          ))}
        </div>
      </Card>
    </>
  );
}

function World() {
  const s = useGame((g) => g.s)!;
  const travel = useGame((g) => g.travel);
  const here = PLACE[s.player.place];
  const dests = (here?.adj ?? []).map((id) => PLACE[id]).filter(Boolean);
  const all = PLACES.filter((p) => p.layer === "mortal");
  return (
    <>
      <p className="mb-2 text-xs text-muted">Travel is hours, gold, and events — not a teleport.</p>
      <Card>
        <p className="font-display text-sm text-gold">Roads from here</p>
        <ul className="mt-2 space-y-2">
          {dests.map((p) => (
            <li key={p.id}>
              <button onClick={() => travel(p.id)} className="flex min-h-12 w-full items-center justify-between rounded-lg border border-line px-3 text-left">
                <span>
                  <span className="block text-sm">{p.name}</span>
                  <span className="text-[11px] text-muted">{p.hours || 3}h · {p.gold}g · {p.layer}</span>
                </span>
                <span className="text-xs text-gold">Walk</span>
              </button>
            </li>
          ))}
        </ul>
      </Card>
      <Card>
        <p className="font-display text-sm text-gold">Mortal map</p>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {all.map((p) => (
            <button key={p.id} onClick={() => travel(p.id)} className="overflow-hidden rounded-lg border border-line text-left">
              <img src={p.art} alt="" className="h-16 w-full object-cover" />
              <span className="block px-2 py-1 text-[11px]">{p.name}</span>
            </button>
          ))}
        </div>
      </Card>
    </>
  );
}

function Heaven() {
  const s = useGame((g) => g.s)!;
  const travel = useGame((g) => g.travel);
  const go = useGame((g) => g.go);
  const here = PLACE[s.player.place];
  const districts = PLACES.filter((p) => p.layer === "heaven");
  const inHeaven = here?.layer === "heaven";
  return (
    <>
      <img src="/art/heaven-market.png" alt="" className="mb-3 h-40 w-full rounded-xl object-cover" />
      <p className="mb-2 text-sm text-bone">Heaven is a city. Districts, jobs, law, and a market that sells hours.</p>
      {!inHeaven ? (
        <button onClick={() => travel("heaven_gate")} className="mb-3 min-h-12 w-full rounded-lg bg-gold font-display text-ink">
          Ascend to Heaven Gate (realm 5+)
        </button>
      ) : (
        <Card>
          <p className="font-display text-sm text-gold">Walk the city</p>
          <ul className="mt-2 space-y-2">
            {districts.map((p) => (
              <li key={p.id}>
                <button onClick={() => travel(p.id)} className={`flex min-h-12 w-full items-center justify-between rounded-lg border px-3 text-left ${p.id === s.player.place ? "border-gold" : "border-line"}`}>
                  <span>
                    <span className="block text-sm">{p.name}</span>
                    <span className="text-[11px] text-muted">{p.kind} · {p.blurb}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </Card>
      )}
      <div className="grid grid-cols-2 gap-2">
        <Quick onClick={() => go("people")} icon={<Users className="size-4" />} label="Souls here" />
        <Quick onClick={() => go("black")} icon={<Cloud className="size-4" />} label="Under-Vein" />
        <Quick onClick={() => go("divine")} icon={<Cloud className="size-4" />} label="Divine" />
        <Quick onClick={() => go("primordial")} icon={<Cloud className="size-4" />} label="Primordial" />
      </div>
    </>
  );
}

function Layer({ layer }: { layer: "divine" | "primordial" }) {
  const travel = useGame((g) => g.travel);
  const list = PLACES.filter((p) => p.layer === layer);
  return (
    <>
      <p className="mb-2 text-sm">{layer === "divine" ? "A civilization of verdicts and thunder-cities." : "The world before names. It still wants them back."}</p>
      {list.map((p) => (
        <button key={p.id} onClick={() => travel(p.id)} className="mb-2 w-full overflow-hidden rounded-xl border border-line text-left">
          <img src={p.art} alt="" className="h-24 w-full object-cover" />
          <div className="p-3">
            <p className="font-display text-gold">{p.name}</p>
            <p className="text-xs text-muted">{p.blurb}</p>
          </div>
        </button>
      ))}
    </>
  );
}

function Sect() {
  const s = useGame((g) => g.s)!;
  const join = useGame((g) => g.join);
  const hall = useGame((g) => g.hall);
  const [nm, setNm] = useState("");
  const [doc, setDoc] = useState("");
  const found = useGame((g) => g.found);
  const sect = SECTS.find((x) => x.id === s.player.sect);
  return (
    <>
      {!s.player.sect ? (
        <Card>
          <p className="font-display text-sm text-gold">Join a house</p>
          {SECTS.filter((x) => x.place === s.player.place || x.id === "silent_blade").map((x) => (
            <button key={x.id} onClick={() => join(x.id)} className="mt-2 min-h-12 w-full rounded-lg border border-line px-3 text-left">
              <span className="block text-sm">{x.name}</span>
              <span className="text-[11px] text-muted">{x.motto}</span>
            </button>
          ))}
        </Card>
      ) : (
        <>
          <Card>
            <p className="font-display text-gold">{sect?.name ?? s.world.foundedSect?.name}</p>
            <p className="text-xs text-muted">Rank {s.player.rank} · Treasury {s.world.sectGold}g</p>
            <p className="mt-2 text-xs">Factions: {Object.entries(s.world.sectPolitics).map(([k, v]) => `${k} ${v}`).join(" · ")}</p>
          </Card>
          {HALLS.map((h) => (
            <button key={h.id} onClick={() => hall(h.id)} className="mb-2 flex min-h-12 w-full items-center justify-between rounded-xl border border-line bg-paper px-3">
              <span>
                <span className="block text-sm">{h.name}</span>
                <span className="text-[11px] text-muted">{h.act}</span>
              </span>
              <span className="text-xs text-gold">4h</span>
            </button>
          ))}
        </>
      )}
      <Card>
        <p className="font-display text-sm text-gold">Found your own</p>
        <input value={nm} onChange={(e) => setNm(e.target.value)} placeholder="Sect name" className="mt-2 min-h-11 w-full rounded-lg border border-line bg-ink px-3 text-sm" />
        <input value={doc} onChange={(e) => setDoc(e.target.value)} placeholder="Doctrine" className="mt-2 min-h-11 w-full rounded-lg border border-line bg-ink px-3 text-sm" />
        <button onClick={() => found(nm, doc)} className="mt-2 min-h-12 w-full rounded-lg border border-gold/40 text-gold">Raise a banner (realm 4+)</button>
      </Card>
    </>
  );
}

function War() {
  const s = useGame((g) => g.s)!;
  const march = useGame((g) => g.warMarch);
  const fight = useGame((g) => g.warFight);
  const tax = useGame((g) => g.tax);
  const royal = s.player.origin === "royal" || s.player.realm >= 4 || s.player.mandate > 10;
  if (!royal) {
    return (
      <Card>
        <p className="font-display text-gold">Citizen levy</p>
        <p className="mt-1 text-sm text-muted">You are not the crown. You can still volunteer.</p>
        {s.world.fronts.map((f) => (
          <button key={f.id} onClick={() => fight(f.id)} className="mt-2 min-h-12 w-full rounded-lg border border-line text-sm">
            Volunteer at {f.name}
          </button>
        ))}
      </Card>
    );
  }
  return (
    <>
      <Card>
        <p className="font-display text-gold">Two purses</p>
        <p className="text-sm">Personal {s.player.gold}g · Treasury {s.kingdom.gold}g · Tax {s.kingdom.tax}% · Legitimacy {s.kingdom.legitimacy}</p>
        <button onClick={tax} className="mt-2 min-h-12 w-full rounded-lg border border-line">Raise taxes (prices will answer)</button>
      </Card>
      <Card>
        <p className="font-display text-sm text-gold">Campaign map</p>
        <p className="text-xs text-muted">{s.world.war ? "War is live. Time moves the fronts." : "Peace is a rumor with an expiration."}</p>
        {s.world.fronts.map((f) => (
          <div key={f.id} className="mt-2 rounded-lg border border-line p-2">
            <p className="text-sm">{f.name} · {f.control} · siege {Math.floor(f.siege)}%</p>
            <div className="mt-1 flex gap-2">
              <button onClick={() => march(f.id)} className="min-h-11 flex-1 rounded-md bg-gold/20 text-xs text-gold">March 10h</button>
              <button onClick={() => fight(f.id)} className="min-h-11 flex-1 rounded-md border border-line text-xs">Join battle</button>
            </div>
          </div>
        ))}
      </Card>
      <Card>
        <p className="font-display text-sm text-gold">Armies</p>
        {s.world.armies.map((a) => (
          <p key={a.id} className="mt-1 text-xs">{a.name} · {a.size} · morale {a.morale} · supply {a.supplies} · {a.loc}</p>
        ))}
      </Card>
    </>
  );
}

function People() {
  const s = useGame((g) => g.s)!;
  const talk = useGame((g) => g.talk);
  const list = nearby(s);
  return (
    <>
      <p className="mb-2 text-xs text-muted">{list.length} souls on this street. They have jobs, hours, and memory.</p>
      {list.slice(0, 12).map((n) => (
        <div key={n.id} className="mb-3 overflow-hidden rounded-xl border border-line bg-paper">
          <div className="flex gap-3 p-2">
            <img src={n.portrait} alt="" className="h-20 w-16 rounded-md object-cover object-top" />
            <div className="min-w-0 flex-1">
              <p className="font-display text-sm text-gold-soft">{n.name}</p>
              <p className="text-[11px] text-muted">{n.title} · {n.job} · now {n.schedule}</p>
              <p className="text-[11px] text-muted">Age {n.age.toFixed(0)} · realm {n.realm} · {n.wealth}g · {n.destiny}</p>
              {n.memory[0] ? <p className="text-[11px] text-gold">Remembers: {n.memory[n.memory.length - 1]}</p> : null}
              {n.rival ? <p className="text-[11px] text-blood">Rival</p> : null}
              {n.nemesis ? <p className="text-[11px] text-blood">Nemesis</p> : null}
            </div>
          </div>
          <div className="grid grid-cols-5 gap-1 p-2 pt-0">
            {(["kind", "gift", "insult", "recruit", "scheme"] as const).map((k) => (
              <button key={k} onClick={() => talk(n.id, k)} className="min-h-10 rounded-md border border-line text-[10px] capitalize">{k}</button>
            ))}
          </div>
        </div>
      ))}
    </>
  );
}

function Market() {
  const act = useGame((g) => g.act);
  const s = useGame((g) => g.s)!;
  return (
    <Card>
      <p className="font-display text-gold">Hourglass Row</p>
      <p className="text-xs text-muted">Prices ×{s.world.prices.toFixed(2)}. Time also obeys coin.</p>
      {s.world.activities.map((a) => (
        <button key={a.id} onClick={() => act(a.id)} className="mt-2 min-h-12 w-full rounded-lg border border-line text-sm">{a.title}</button>
      ))}
    </Card>
  );
}

function Black() {
  const buy = useGame((g) => g.buy);
  const s = useGame((g) => g.s)!;
  const go = useGame((g) => g.go);
  return (
    <>
      <button onClick={() => go("heaven")} className="mb-2 text-xs text-gold">← Heaven</button>
      <img src="/art/heaven-market.png" alt="" className="mb-3 h-32 w-full rounded-xl object-cover opacity-80" />
      <Card>
        <p className="font-display text-gold">Under-Vein</p>
        <p className="text-xs text-muted">Wanted {s.player.wanted}. Heaven law {s.world.heavenLaw}.</p>
        {[
          ["Forbidden fire sutra", 90],
          ["False name papers", 45],
          ["Stolen hourglass", 120],
          ["Assassin contract", 70],
        ].map(([item, cost]) => (
          <button key={String(item)} onClick={() => buy(String(item), Number(cost))} className="mt-2 min-h-12 w-full rounded-lg border border-line text-left px-3 text-sm">
            {item} · {cost}g
          </button>
        ))}
      </Card>
    </>
  );
}

function Society() {
  const hours = useGame((g) => g.hours);
  return (
    <Card>
      <p className="font-display text-gold">Ashen Bell Society</p>
      <p className="text-sm text-muted">A hidden order. Bells remember debts.</p>
      <button onClick={() => hours(5)} className="mt-3 min-h-12 w-full rounded-lg bg-gold text-ink">Take a silent contract (5h)</button>
    </Card>
  );
}

function Dream() {
  const s = useGame((g) => g.s)!;
  const go = useGame((g) => g.go);
  if (!s.dream) return <p className="text-sm text-muted">The moon is quiet. Sleep somewhere long enough.</p>;
  return (
    <Card>
      <p className="font-display text-gold">{s.dream.title}</p>
      <p className="mt-2 text-sm">{s.dream.text}</p>
      <p className="mt-2 text-xs text-muted">Dreams are not always honest.</p>
      <button onClick={() => go("home")} className="mt-3 min-h-12 w-full rounded-lg border border-line">Wake</button>
    </Card>
  );
}

function Inner() {
  const s = useGame((g) => g.s)!;
  const pick = useGame((g) => g.innerGo);
  if (!s.inner) return <p className="text-muted">No inner landscape open.</p>;
  return (
    <Card>
      <p className="font-display text-gold">{s.inner.title}</p>
      {s.inner.path.map((p) => <p key={p} className="mt-2 text-sm">{p}</p>)}
      <div className="mt-3 grid gap-2">
        <button onClick={() => pick(0)} className="min-h-12 rounded-lg bg-gold text-ink">Forgive</button>
        <button onClick={() => pick(1)} className="min-h-12 rounded-lg border border-line">Fight</button>
        <button onClick={() => pick(2)} className="min-h-12 rounded-lg border border-line">Walk around</button>
      </div>
    </Card>
  );
}

function Ruins() {
  const ruin = useGame((g) => g.ruin);
  const s = useGame((g) => g.s)!;
  return (
    <>
      <Card>
        <p className="font-display text-gold">Lost civilizations</p>
        <p className="text-sm text-muted">Cinder, Unmade City, First Dark. Dig. Pieces connect.</p>
        <button onClick={ruin} className="mt-3 min-h-12 w-full rounded-lg bg-gold text-ink">Excavate 6h</button>
      </Card>
      <Card>
        <p className="text-xs text-muted">Pack: {s.player.inventory.join(", ") || "empty"}</p>
      </Card>
    </>
  );
}

function Companions() {
  const s = useGame((g) => g.s)!;
  return (
    <Card>
      <p className="font-display text-gold">Companions & disciples</p>
      <p className="text-sm">Master: {s.player.master || "none"}</p>
      <p className="text-sm">Disciples: {s.player.disciples.length}</p>
      <p className="mt-2 text-xs text-muted">Recruit from People. Loyalty is treatment, not a number that never moves.</p>
    </Card>
  );
}

function Artifacts() {
  const s = useGame((g) => g.s)!;
  const artifact = useGame((g) => g.artifact);
  return (
    <>
      <button onClick={artifact} className="mb-3 min-h-12 w-full rounded-lg bg-gold text-ink">Awaken an artifact (80g, 8h)</button>
      {s.player.artifacts.map((a) => (
        <Card key={a.id}>
          <p className="font-display text-gold">{a.name}</p>
          <p className="text-sm">{a.mood} · loyalty {a.loyalty}</p>
        </Card>
      ))}
    </>
  );
}

function Rumors() {
  const s = useGame((g) => g.s)!;
  return (
    <Card>
      <p className="font-display text-gold">Rumor mill</p>
      {s.world.rumors.map((r, i) => (
        <p key={i} className="mt-2 text-sm">{r.text} <span className="text-muted">({r.age.toFixed(1)}d old)</span></p>
      ))}
    </Card>
  );
}

function Identity() {
  const s = useGame((g) => g.s)!;
  const hours = useGame((g) => g.hours);
  return (
    <Card>
      <p className="font-display text-gold">False name</p>
      <p className="text-sm">Now: {displayName(s)} {s.player.identityHidden ? "(hidden)" : "(true)"}</p>
      <button
        onClick={() => {
          s.player.identityHidden = !s.player.identityHidden;
          s.player.alias = s.player.alias || "Dust-Walker";
          hours(2);
        }}
        className="mt-3 min-h-12 w-full rounded-lg border border-line"
      >
        Toggle alias (2h)
      </button>
    </Card>
  );
}

function Combat() {
  const s = useGame((g) => g.s)!;
  const hit = useGame((g) => g.hit);
  const c = s.combat;
  if (!c) return <p>No fight.</p>;
  return (
    <Card>
      <p className="font-display text-gold">{c.foe}</p>
      <p className="text-xs">Them {c.hp}/{c.mhp} · You {c.php}/{c.pmhp}</p>
      <div className="mt-2 h-2 rounded bg-ink"><div className="h-full bg-blood" style={{ width: `${(c.hp / c.mhp) * 100}%` }} /></div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        <button onClick={() => hit("strike")} className="min-h-12 rounded-lg bg-gold text-ink">Strike</button>
        <button onClick={() => hit("technique")} className="min-h-12 rounded-lg border border-line">Art</button>
        <button onClick={() => hit("flee")} className="min-h-12 rounded-lg border border-line">Flee</button>
      </div>
      <ul className="mt-3 text-xs text-muted">{c.log.slice(-6).map((l, i) => <li key={i}>{l}</li>)}</ul>
    </Card>
  );
}

function More() {
  const go = useGame((g) => g.go);
  const wipe = useGame((g) => g.wipe);
  const [taps, setTaps] = useState(0);
  const items: { id: ScreenId; label: string }[] = [
    { id: "cultivate", label: "Cultivate / time" },
    { id: "people", label: "NPC lives" },
    { id: "character", label: "Identity card" },
    { id: "market", label: "Markets" },
    { id: "black", label: "Black market" },
    { id: "society", label: "Secret society" },
    { id: "dream", label: "Dreams" },
    { id: "ruins", label: "Archaeology" },
    { id: "companion", label: "Disciples" },
    { id: "artifact", label: "Artifacts" },
    { id: "rumor", label: "Rumors" },
    { id: "identity", label: "False identity" },
    { id: "divine", label: "Divine Realm" },
    { id: "primordial", label: "Primordial Chaos" },
  ];
  return (
    <>
      {items.map((it) => (
        <button key={it.id} onClick={() => go(it.id)} className="mb-2 min-h-12 w-full rounded-xl border border-line bg-paper px-3 text-left text-sm">{it.label}</button>
      ))}
      <button
        onClick={() => { const n = taps + 1; setTaps(n); if (n >= 7) go("sandbox"); }}
        className="mt-4 w-full text-center text-[10px] text-muted"
      >
        Year 614 · Path of the Immortal
      </button>
      <button onClick={wipe} className="mt-2 w-full text-center text-[10px] text-blood">End this life</button>
    </>
  );
}

function Sandbox() {
  const box = useGame((g) => g.box);
  const cmds = ["heaven", "divine", "chaos", "king", "war", "break", "age", "rival", "nemesis", "gold", "year"];
  return (
    <Card>
      <p className="font-display text-gold">Developer sandbox</p>
      <p className="text-xs text-muted">Hidden. Tests the world without grinding.</p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {cmds.map((c) => (
          <button key={c} onClick={() => box(c)} className="min-h-11 rounded-lg border border-line text-xs">{c}</button>
        ))}
      </div>
    </Card>
  );
}

function SkipModal() {
  const s = useGame((g) => g.s)!;
  const yes = useGame((g) => g.doSkip);
  const no = useGame((g) => g.cancelSkip);
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-ink/70 p-4">
      <div className="w-full max-w-lg rounded-2xl border border-gold/40 bg-paper p-4">
        <p className="font-display text-gold">Skip {s.confirmSkip?.years} year(s)?</p>
        <p className="mt-2 text-sm text-bone">{s.confirmSkip?.preview}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button onClick={no} className="min-h-12 rounded-lg border border-line">Cancel</button>
          <button onClick={yes} className="min-h-12 rounded-lg bg-gold text-ink">Confirm</button>
        </div>
      </div>
    </div>
  );
}
