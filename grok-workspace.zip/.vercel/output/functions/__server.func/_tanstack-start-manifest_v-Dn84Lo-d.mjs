//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dn84Lo-d.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Dx1s2gUD.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dx1s2gUD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-_i8eEkxI.js"]
	}
} });
//#endregion
export { tsrStartManifest };
