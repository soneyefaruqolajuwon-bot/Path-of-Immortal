import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as Map, d as Crown, f as Cloud, i as ScrollText, l as Landmark, o as Pause, r as Swords, s as Menu, t as Users, u as House } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BnBKtZuq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MS_PER_GAME_DAY = 1728e4;
var HOURS_YEAR = 8640;
var FOUNDATION_MUL = {
	broken: .7,
	ordinary: 1,
	solid: 1.15,
	excellent: 1.35,
	heavenly: 1.7,
	primordial: 2.2
};
var REALM_NAME = [
	"Mortal Shell",
	"Qi Gathering",
	"Foundation",
	"Core Formation",
	"Nascent Soul",
	"Soul Transformation",
	"Void Refining",
	"Body Integration",
	"Mahayana",
	"Tribulation",
	"Immortal"
];
function realmBand(r) {
	if (r <= 2) return "Early";
	if (r <= 5) return "Middle";
	if (r <= 8) return "Late";
	return "Peak";
}
function realmLabel(r, stage = 1) {
	const n = REALM_NAME[Math.max(0, Math.min(10, r))] ?? "Unknown";
	const roman = [
		"",
		"I",
		"II",
		"III",
		"IV",
		"V",
		"VI",
		"VII",
		"VIII",
		"IX",
		"X"
	][stage] ?? "";
	return `${n} · ${realmBand(r)} ${roman}`.trim();
}
var DAO = [
	{
		id: "sword",
		name: "Sword",
		rival: "shadow",
		blurb: "Edge that remembers every cut."
	},
	{
		id: "fire",
		name: "Fire",
		rival: "water",
		blurb: "Hunger that eats heaven."
	},
	{
		id: "water",
		name: "Water",
		rival: "fire",
		blurb: "Patience that drowns empires."
	},
	{
		id: "life",
		name: "Life",
		rival: "death",
		blurb: "Green that refuses the grave."
	},
	{
		id: "death",
		name: "Death",
		rival: "life",
		blurb: "The last honest teacher."
	},
	{
		id: "order",
		name: "Order",
		rival: "chaos",
		blurb: "Law that binds even gods."
	},
	{
		id: "chaos",
		name: "Chaos",
		rival: "order",
		blurb: "The first dark, still hungry."
	},
	{
		id: "shadow",
		name: "Shadow",
		rival: "sword",
		blurb: "Names that never reach the ledger."
	},
	{
		id: "time",
		name: "Time",
		rival: "chaos",
		blurb: "Hours sold, years stolen."
	}
];
var PLACES = [
	{
		id: "ashroot",
		name: "Ashroot Village",
		layer: "mortal",
		kind: "village",
		art: "/art/ashroot.png",
		blurb: "Mud, well-water, and a mountain that pretends not to watch.",
		hours: 0,
		gold: 0,
		reqRealm: 0,
		adj: [
			"coil_road",
			"greenfen",
			"cinder"
		]
	},
	{
		id: "coil_road",
		name: "Pale Coil Road",
		layer: "mortal",
		kind: "road",
		art: "/art/coil-palace.png",
		blurb: "Banners of a dying house. Tolls first, justice later.",
		hours: 6,
		gold: 8,
		reqRealm: 0,
		adj: [
			"ashroot",
			"coil_palace",
			"salt_port"
		]
	},
	{
		id: "coil_palace",
		name: "Pale Coil Palace",
		layer: "mortal",
		kind: "capital",
		art: "/art/coil-palace.png",
		blurb: "Wet black stone. A throne that still remembers blood.",
		hours: 8,
		gold: 20,
		reqRealm: 0,
		adj: [
			"coil_road",
			"silent_blade",
			"iron_fort"
		]
	},
	{
		id: "salt_port",
		name: "Salt Crown Port",
		layer: "mortal",
		kind: "port",
		art: "/art/salt-port.png",
		blurb: "Two gods, one harbor. All tariffs bow.",
		hours: 10,
		gold: 18,
		reqRealm: 0,
		adj: [
			"coil_road",
			"jade_harbor",
			"heaven_gate"
		]
	},
	{
		id: "silent_blade",
		name: "Silent Blade Sect",
		layer: "mortal",
		kind: "sect",
		art: "/art/coil-palace.png",
		blurb: "Bells that remember every oath broken here.",
		hours: 8,
		gold: 12,
		reqRealm: 1,
		adj: ["coil_palace", "mist_temple"]
	},
	{
		id: "mist_temple",
		name: "Mist Temple",
		layer: "mortal",
		kind: "temple",
		art: "/art/ashroot.png",
		blurb: "Fog that edits memory if you stay the night.",
		hours: 7,
		gold: 6,
		reqRealm: 1,
		adj: ["silent_blade", "greenfen"]
	},
	{
		id: "greenfen",
		name: "Greenfen",
		layer: "mortal",
		kind: "farm",
		art: "/art/ashroot.png",
		blurb: "Rot and bloom share a ditch.",
		hours: 4,
		gold: 4,
		reqRealm: 0,
		adj: ["ashroot", "mist_temple"]
	},
	{
		id: "iron_fort",
		name: "Iron Fort",
		layer: "mortal",
		kind: "fort",
		art: "/art/coil-palace.png",
		blurb: "The kingdom's last honest wall.",
		hours: 9,
		gold: 10,
		reqRealm: 2,
		adj: ["coil_palace", "cinder"]
	},
	{
		id: "cinder",
		name: "Cinder Ruins",
		layer: "mortal",
		kind: "ruin",
		art: "/art/ashroot.png",
		blurb: "A city that chose fire over surrender.",
		hours: 8,
		gold: 5,
		reqRealm: 2,
		adj: ["ashroot", "iron_fort"]
	},
	{
		id: "jade_harbor",
		name: "Jade Harbor",
		layer: "mortal",
		kind: "market",
		art: "/art/salt-port.png",
		blurb: "Silk, poisons, and names for sale.",
		hours: 9,
		gold: 14,
		reqRealm: 1,
		adj: ["salt_port"]
	},
	{
		id: "heaven_gate",
		name: "Heaven Gate",
		layer: "heaven",
		kind: "gate",
		art: "/art/heaven-market.png",
		blurb: "Clouds underfoot. Your mortal name is already being rewritten.",
		hours: 16,
		gold: 40,
		reqRealm: 5,
		adj: [
			"salt_port",
			"court_square",
			"heaven_port"
		]
	},
	{
		id: "court_square",
		name: "Court of Measures",
		layer: "heaven",
		kind: "government",
		art: "/art/heaven-market.png",
		blurb: "Records. Judge. Allocate. Continue.",
		hours: 3,
		gold: 0,
		reqRealm: 5,
		adj: [
			"heaven_gate",
			"time_market",
			"noble_terrace",
			"law_prison"
		]
	},
	{
		id: "time_market",
		name: "Hourglass Row",
		layer: "heaven",
		kind: "market",
		art: "/art/heaven-market.png",
		blurb: "Buy. Borrow. Extend. Forget.",
		hours: 2,
		gold: 0,
		reqRealm: 5,
		adj: [
			"court_square",
			"craft_forge",
			"cloud_inn",
			"poor_mist"
		]
	},
	{
		id: "noble_terrace",
		name: "Noble Terrace",
		layer: "heaven",
		kind: "noble",
		art: "/art/heaven-market.png",
		blurb: "White stone, gold law, no mud allowed.",
		hours: 2,
		gold: 0,
		reqRealm: 6,
		adj: [
			"court_square",
			"sect_district",
			"cultivate_peak"
		]
	},
	{
		id: "poor_mist",
		name: "Mist Wards",
		layer: "heaven",
		kind: "slum",
		art: "/art/heaven-market.png",
		blurb: "Immortals who still owe rent.",
		hours: 2,
		gold: 0,
		reqRealm: 5,
		adj: [
			"time_market",
			"under_vein",
			"heal_hall"
		]
	},
	{
		id: "sect_district",
		name: "Nine Heaven Courts",
		layer: "heaven",
		kind: "sect",
		art: "/art/heaven-market.png",
		blurb: "Three heavenly sects share one sky and none of the credit.",
		hours: 3,
		gold: 0,
		reqRealm: 5,
		adj: ["noble_terrace", "cultivate_peak"]
	},
	{
		id: "cultivate_peak",
		name: "Still Cloud Peak",
		layer: "heaven",
		kind: "cultivate",
		art: "/art/heaven-market.png",
		blurb: "The air itself cultivates you — for a price in years.",
		hours: 3,
		gold: 0,
		reqRealm: 5,
		adj: ["noble_terrace", "sect_district"]
	},
	{
		id: "law_prison",
		name: "Unbroken Cells",
		layer: "heaven",
		kind: "prison",
		art: "/art/heaven-market.png",
		blurb: "What is taken is not lost. Only reassigned.",
		hours: 3,
		gold: 0,
		reqRealm: 5,
		adj: ["court_square"]
	},
	{
		id: "heal_hall",
		name: "White Bone Hall",
		layer: "heaven",
		kind: "heal",
		art: "/art/heaven-market.png",
		blurb: "They mend the body. They invoice the soul.",
		hours: 2,
		gold: 0,
		reqRealm: 5,
		adj: ["poor_mist", "cloud_inn"]
	},
	{
		id: "craft_forge",
		name: "Star Anvil",
		layer: "heaven",
		kind: "craft",
		art: "/art/heaven-market.png",
		blurb: "Artifacts argue while they are still being made.",
		hours: 2,
		gold: 0,
		reqRealm: 5,
		adj: ["time_market"]
	},
	{
		id: "cloud_inn",
		name: "Longer Tomorrow Inn",
		layer: "heaven",
		kind: "inn",
		art: "/art/heaven-market.png",
		blurb: "Hours, days, seasons, years — rooms by the century.",
		hours: 1,
		gold: 0,
		reqRealm: 5,
		adj: ["time_market", "heal_hall"]
	},
	{
		id: "heaven_port",
		name: "Cloud Pier",
		layer: "heaven",
		kind: "port",
		art: "/art/salt-port.png",
		blurb: "Ships that sail storm-law, not water.",
		hours: 3,
		gold: 0,
		reqRealm: 5,
		adj: ["heaven_gate"]
	},
	{
		id: "under_vein",
		name: "Under-Vein",
		layer: "heaven",
		kind: "secret",
		art: "/art/heaven-market.png",
		blurb: "Heaven's black market: forbidden manuals, fake names, true knives.",
		hours: 3,
		gold: 0,
		reqRealm: 5,
		adj: ["poor_mist"]
	},
	{
		id: "law_palace",
		name: "Palace of Unbroken Law",
		layer: "divine",
		kind: "city",
		art: "/art/heaven-market.png",
		blurb: "A civilization of verdicts. Breathing is a permit.",
		hours: 24,
		gold: 80,
		reqRealm: 8,
		adj: ["heaven_gate", "thunder_sea"]
	},
	{
		id: "thunder_sea",
		name: "Thunder Sea",
		layer: "divine",
		kind: "wild",
		art: "/art/salt-port.png",
		blurb: "Lightning with a census. Cities on the bolts.",
		hours: 20,
		gold: 60,
		reqRealm: 8,
		adj: ["law_palace", "immortal_peak"]
	},
	{
		id: "immortal_peak",
		name: "Nameless Peak",
		layer: "divine",
		kind: "cultivate",
		art: "/art/coil-palace.png",
		blurb: "Where immortals go to stop being people.",
		hours: 18,
		gold: 50,
		reqRealm: 9,
		adj: ["thunder_sea"]
	},
	{
		id: "chaos_shore",
		name: "Chaos Shore",
		layer: "primordial",
		kind: "wild",
		art: "/art/key-art.png",
		blurb: "The world before names. It still wants them back.",
		hours: 40,
		gold: 120,
		reqRealm: 10,
		adj: ["immortal_peak", "unmade"]
	},
	{
		id: "unmade",
		name: "The Unmade City",
		layer: "primordial",
		kind: "ruin",
		art: "/art/key-art.png",
		blurb: "Architecture that remembers being a language.",
		hours: 30,
		gold: 90,
		reqRealm: 10,
		adj: ["chaos_shore", "first_dark"]
	},
	{
		id: "first_dark",
		name: "First Dark",
		layer: "primordial",
		kind: "secret",
		art: "/art/key-art.png",
		blurb: "Before light. Before law. Before you.",
		hours: 40,
		gold: 0,
		reqRealm: 10,
		adj: ["unmade"]
	}
];
var PLACE = Object.fromEntries(PLACES.map((p) => [p.id, p]));
var SECTS = [
	{
		id: "silent_blade",
		name: "Silent Blade",
		dao: "sword",
		place: "silent_blade",
		motto: "A blade remembers."
	},
	{
		id: "pale_coil",
		name: "House of the Pale Coil",
		dao: "order",
		place: "coil_palace",
		motto: "Silence wears gold."
	},
	{
		id: "nine_heaven",
		name: "Nine Heaven Court",
		dao: "order",
		place: "sect_district",
		motto: "Measure all things."
	},
	{
		id: "thunder_court",
		name: "Thunder Court",
		dao: "fire",
		place: "sect_district",
		motto: "Law is a storm with a ledger."
	},
	{
		id: "unbroken_law",
		name: "Unbroken Law",
		dao: "order",
		place: "law_palace",
		motto: "What is taken is reassigned."
	}
];
var FACTIONS = [
	"loyalist",
	"reform",
	"ambition",
	"shadow",
	"merchant"
];
var HALLS = [
	{
		id: "library",
		name: "Scripture Library",
		act: "Browse manuals"
	},
	{
		id: "train",
		name: "Training Hall",
		act: "Spar a disciple"
	},
	{
		id: "alchemy",
		name: "Alchemy Hall",
		act: "Refine a pill"
	},
	{
		id: "treasury",
		name: "Treasury",
		act: "Audit the books"
	},
	{
		id: "mission",
		name: "Mission Hall",
		act: "Take a contract"
	},
	{
		id: "elder",
		name: "Elder Hall",
		act: "Sit the council"
	},
	{
		id: "court",
		name: "Disciples' Court",
		act: "Judge a dispute"
	},
	{
		id: "warhall",
		name: "War Hall",
		act: "Plan a strike"
	},
	{
		id: "leader",
		name: "Leader Residence",
		act: "Petition the seat"
	}
];
var JOBS = [
	{
		id: "well",
		name: "Draw well-water",
		hours: 3,
		gold: 6,
		place: "ashroot"
	},
	{
		id: "hoe",
		name: "Hoe the fen",
		hours: 5,
		gold: 9,
		place: "greenfen"
	},
	{
		id: "toll",
		name: "Collect a road toll",
		hours: 4,
		gold: 14,
		place: "coil_road"
	},
	{
		id: "dock",
		name: "Unload salt barges",
		hours: 6,
		gold: 18,
		place: "salt_port"
	},
	{
		id: "hour",
		name: "Sell an hourglass",
		hours: 4,
		gold: 40,
		place: "time_market"
	},
	{
		id: "scribe",
		name: "Copy a verdict",
		hours: 5,
		gold: 32,
		place: "court_square"
	},
	{
		id: "inn",
		name: "Keep the inn",
		hours: 6,
		gold: 28,
		place: "cloud_inn"
	},
	{
		id: "forge",
		name: "Pump the star anvil",
		hours: 5,
		gold: 36,
		place: "craft_forge"
	}
];
function portraitOf(gender, origin) {
	if (gender === "female" && origin === "royal") return "/art/hero-female-royal.png";
	if (gender === "female") return "/art/hero-female-commoner.png";
	return "/art/hero-male-commoner.png";
}
function qiNeed(realm, stage) {
	return Math.floor(40 * Math.pow(1.45, realm) * (.6 + stage * .4));
}
function lifespanOf(realm, foundation) {
	const base = [
		70,
		90,
		140,
		220,
		400,
		700,
		1200,
		2e3,
		3500,
		6e3,
		12e3
	][Math.min(10, realm)] ?? 70;
	return Math.floor(base * FOUNDATION_MUL[foundation]);
}
var NAMED_NPCS = [
	{
		id: "shen",
		name: "Coil-King Shen",
		title: "Throne of Fading Heavens",
		portrait: "/art/npc-shen.png",
		place: "coil_palace",
		job: "king",
		realm: 6,
		wealth: 9e4,
		age: 71,
		gender: "male",
		faction: "loyalist",
		goal: "Die crowned, not remembered as a footnote.",
		destiny: "Last king — or first immortal emperor",
		schedule: "Court at dawn, wine at dusk, war in between."
	},
	{
		id: "lady",
		name: "Lady of the Pale Coil",
		title: "Silence Wears Gold",
		portrait: "/art/npc-lady.png",
		place: "coil_palace",
		job: "princess",
		realm: 4,
		wealth: 18e3,
		age: 24,
		gender: "female",
		faction: "ambition",
		goal: "A throne that does not need a husband.",
		destiny: "Future empress — if she is not first a traitor",
		schedule: "Dawn sword, noon ledgers, midnight letters."
	},
	{
		id: "wren",
		name: "Wren of Greenfen",
		title: "Bloom in the Rot",
		portrait: "/art/npc-wren.png",
		place: "greenfen",
		job: "herbalist",
		realm: 2,
		wealth: 40,
		age: 19,
		gender: "female",
		faction: "reform",
		goal: "Keep one field alive through the next famine.",
		destiny: "Saint of the lower world",
		schedule: "Dawn herbs, noon clinic, dusk at the well."
	},
	{
		id: "saffron",
		name: "Saffron of the Dust Road",
		title: "All Things Have a Price",
		portrait: "/art/npc-saffron.png",
		place: "salt_port",
		job: "merchant",
		realm: 3,
		wealth: 4200,
		age: 27,
		gender: "male",
		faction: "merchant",
		goal: "Own the harbor the gods tax.",
		destiny: "King of a market, never a throne",
		schedule: "Docks at first light, auction at dusk."
	},
	{
		id: "kael",
		name: "Kael of the Ashen Bell",
		title: "A Blade Remembers",
		portrait: "/art/npc-kael.png",
		place: "silent_blade",
		job: "inner disciple",
		realm: 3,
		wealth: 220,
		age: 22,
		gender: "male",
		faction: "ambition",
		goal: "Surpass whoever last beat him.",
		destiny: "Rival — or the next sect leader",
		schedule: "Spar until the bell, meditate until it cracks."
	},
	{
		id: "farmer",
		name: "Old Farmer of Ashroot",
		title: "Some Choose the Field",
		portrait: "/art/npc-farmer.png",
		place: "ashroot",
		job: "farmer",
		realm: 0,
		wealth: 12,
		age: 67,
		gender: "male",
		faction: "loyalist",
		goal: "See one more harvest.",
		destiny: "Witness. The world keeps him to remember mud.",
		schedule: "Hoe at cockcrow, well at noon, sleep with the hens."
	}
];
var uid = () => Math.random().toString(36).slice(2, 9);
function calendar(hours) {
	const y = EPOCH(hours);
	const dayOfYear = Math.floor(hours / 24 % 360);
	return {
		year: y,
		month: Math.floor(dayOfYear / 30) + 1,
		day: dayOfYear % 30 + 1,
		hour: Math.floor(hours % 24),
		week: Math.floor(dayOfYear / 6) % 6 + 1,
		totalDays: Math.floor(hours / 24)
	};
}
function EPOCH(h) {
	return 614 + Math.floor(h / HOURS_YEAR);
}
function fx(s, t) {
	s.log = [t, ...s.log].slice(0, 80);
	s.world.history = [t, ...s.world.history].slice(0, 200);
}
function rumor(s, text, truth = true) {
	s.world.rumors.unshift({
		text,
		true: truth,
		age: 0
	});
	s.world.rumors = s.world.rumors.slice(0, 40);
}
function powerOf(s) {
	const p = s.player;
	const fm = FOUNDATION_MUL[p.foundation] ?? 1;
	return Math.floor((20 + p.realm * 18 + p.stage * 4) * fm * (1 + p.techniques.length * .08));
}
function extraNpcs() {
	const jobs = [
		"scribe",
		"guard",
		"cook",
		"beggar",
		"priest",
		"smuggler",
		"alchemist",
		"innkeep",
		"soldier",
		"child"
	];
	const places = PLACES.map((p) => p.id);
	const out = [];
	for (let i = 0; i < 36; i++) {
		const place = places[i % places.length];
		const g = i % 2 ? "female" : "male";
		out.push({
			id: "n" + i,
			name: [
				"Ash",
				"Lin",
				"Wei",
				"Yun",
				"Mei",
				"Hao",
				"Qiu",
				"Shen"
			][i % 8] + " " + [
				"of Dust",
				"of Coil",
				"of Salt",
				"of Cloud",
				"of Bell",
				"of Fen"
			][i % 6],
			title: jobs[i % jobs.length],
			portrait: g === "female" ? "/art/hero-female-commoner.png" : "/art/hero-male-commoner.png",
			place,
			job: jobs[i % jobs.length],
			realm: Math.floor(i / 8),
			wealth: 8 + i * 17 % 400,
			age: 12 + i * 13 % 80,
			gender: g,
			faction: FACTIONS[i % FACTIONS.length],
			goal: "Survive the year.",
			destiny: i % 9 === 0 ? "Hidden heir" : "Ordinary thread",
			loyalty: 40 + i * 7 % 50,
			memory: [],
			alive: true,
			schedule: [
				"sleep",
				"work",
				"eat",
				"cultivate",
				"market"
			][Math.floor(i % 24 / 5)] ?? "work",
			relation: 0
		});
	}
	return out;
}
function newGame(opts) {
	const foundation = opts.origin === "royal" ? "solid" : "ordinary";
	const named = NAMED_NPCS.map((n) => ({
		...n,
		loyalty: 50,
		memory: [],
		alive: true,
		relation: 0,
		rival: n.id === "kael"
	}));
	const s = {
		v: 5,
		screen: "home",
		player: {
			name: opts.name.trim() || "Unnamed",
			gender: opts.gender,
			origin: opts.origin,
			dao: opts.dao,
			realm: opts.origin === "royal" ? 1 : 0,
			stage: 1,
			qi: 0,
			foundation,
			lastBreak: "none",
			gold: opts.origin === "royal" ? 800 : 40,
			age: opts.origin === "royal" ? 18 : 16,
			lifespan: lifespanOf(opts.origin === "royal" ? 1 : 0, foundation),
			karma: 0,
			place: opts.origin === "royal" ? "coil_palace" : "ashroot",
			sect: "",
			rank: "none",
			wanted: 0,
			alias: "",
			identityHidden: false,
			soul: [],
			legend: { ashroot: "A nobody from the well." },
			mandate: opts.origin === "royal" ? 20 : 0,
			disciples: [],
			master: "",
			companion: "",
			artifacts: [],
			techniques: opts.origin === "royal" ? ["Coil Court Step"] : ["Breath of Mud"],
			inventory: [],
			height: 50,
			body: 50
		},
		world: {
			totalHours: 6,
			lastSimHour: 6,
			era: "Age of Kingdoms",
			history: ["Year 614. The Pale Coil still holds the valley."],
			rumors: [{
				text: "Ashroot's well steamed green last night.",
				true: true,
				age: 0
			}],
			npcs: [...named, ...extraNpcs()],
			graves: [],
			armies: [{
				id: "coil1",
				name: "Coil Banners",
				side: "coil",
				size: 1200,
				morale: 70,
				supplies: 80,
				loc: "iron_fort",
				general: "Shen"
			}, {
				id: "salt1",
				name: "Salt Crown Fleet-Guard",
				side: "salt",
				size: 900,
				morale: 65,
				supplies: 90,
				loc: "salt_port",
				general: "Saffron"
			}],
			fronts: [
				{
					id: "iron",
					name: "Iron Fort",
					control: "coil",
					siege: 0,
					kind: "fort"
				},
				{
					id: "road",
					name: "Pale Coil Road",
					control: "coil",
					siege: 0,
					kind: "pass"
				},
				{
					id: "port",
					name: "Salt Crown",
					control: "salt",
					siege: 0,
					kind: "city"
				},
				{
					id: "fen",
					name: "Greenfen",
					control: "coil",
					siege: 0,
					kind: "village"
				},
				{
					id: "ash",
					name: "Ashroot",
					control: "coil",
					siege: 0,
					kind: "village"
				}
			],
			treaties: ["Uneasy salt-for-grain pact"],
			buildings: [{
				id: "well",
				name: "Village Well",
				level: 1
			}],
			activities: [],
			journey: null,
			sectGold: 400,
			sectPolitics: {
				loyalist: 40,
				reform: 25,
				ambition: 20,
				shadow: 15
			},
			heavenLaw: 60,
			prices: 1,
			war: false
		},
		kingdom: {
			gold: opts.origin === "royal" ? 12e3 : 8e3,
			tax: 8,
			legitimacy: opts.origin === "royal" ? 55 : 40
		},
		settings: {
			timeSpeed: 1,
			showPower: true
		},
		combat: null,
		log: ["The well remembers your face."],
		confirmSkip: null,
		dream: null,
		inner: null
	};
	refreshBoard(s);
	return s;
}
function addHours(s, h) {
	s.world.totalHours += h;
	const days = h / 24;
	s.player.age += days / 360;
	if (s.player.age > s.player.lifespan) {
		fx(s, "Your lifespan ended. The soul refused the grave — for now.");
		imprint(s, "Survived death");
		s.player.age = s.player.lifespan - 1;
		s.player.karma -= 20;
	}
}
function spendHours(s, h) {
	addHours(s, h);
	simWorld(s, h);
}
function scheduleAt(hour) {
	const t = hour % 24;
	if (t < 6) return "sleep";
	if (t < 8) return "eat";
	if (t < 16) return "work";
	if (t < 19) return "cultivate";
	if (t < 22) return "market";
	return "sleep";
}
function simWorld(s, hours) {
	const steps = Math.max(1, Math.floor(hours));
	for (let i = 0; i < Math.min(steps, 48); i++) {
		const hour = s.world.totalHours - hours + i + 1;
		for (const n of s.world.npcs) {
			if (!n.alive) continue;
			n.schedule = scheduleAt(hour);
			if (i === 0 && hours >= 24) {
				n.age += hours / 24 / 360;
				if (n.job !== "king" && Math.random() < .02) n.wealth += Math.floor((Math.random() - .3) * 20);
				if (n.rival) n.realm = Math.min(n.realm + (Math.random() < .15 ? 1 : 0), 10);
				if (n.nemesis && Math.random() < .08) {
					s.player.wanted += 2;
					fx(s, `${n.name} sent knives in the dark.`);
				}
				if (n.age > 90 + n.realm * 40 && Math.random() < .05) {
					n.alive = false;
					s.world.graves.unshift({
						name: n.name,
						text: `${n.title}. Unfinished: ${n.goal}`,
						hour
					});
					fx(s, `${n.name} died. The field does not pause.`);
				}
			}
		}
	}
	s.world.rumors.forEach((r) => {
		r.age += hours / 24;
	});
	if (s.world.war) tickWar(s, hours);
	if (s.player.sect && hours >= 24) {
		s.world.sectGold += Math.floor(4 * hours / 24);
		const keys = Object.keys(s.world.sectPolitics);
		const k = keys[Math.floor(Math.random() * keys.length)];
		s.world.sectPolitics[k] = Math.max(5, Math.min(70, (s.world.sectPolitics[k] ?? 20) + (Math.random() < .5 ? 1 : -1)));
	}
	if (hours >= 24) {
		if (calendar(s.world.totalHours).day === 1 && s.player.origin === "royal") {
			s.player.gold += 40;
			fx(s, "Royal stipend: 40 gold into your personal purse.");
		}
		s.kingdom.gold += Math.floor(s.kingdom.tax * 3 - 20);
		s.world.prices = Math.max(.6, Math.min(1.8, s.world.prices + (Math.random() - .5) * .05));
	}
	if (Math.random() < hours / 200) s.dream = {
		title: Math.random() < .5 ? "A true dream" : "A lying moon",
		text: Math.random() < .5 ? "Kael of the Ashen Bell trains in a ruined bell-tower. He will find you in three seasons." : "The Coil-King drinks a cup that is already empty. The throne is yours if you take it tonight. (It is not.)",
		lie: Math.random() < .5
	};
	refreshBoard(s);
}
function tickWar(s, hours) {
	const days = hours / 24;
	for (const a of s.world.armies) {
		a.supplies = Math.max(0, a.supplies - days * 2);
		if (a.supplies < 10) a.morale = Math.max(10, a.morale - 3);
		a.size = Math.max(40, a.size - (a.supplies < 5 ? Math.floor(days * 8) : 0));
	}
	for (const f of s.world.fronts) if (f.siege > 0) {
		f.siege += days * 4;
		if (f.siege >= 100) {
			f.control = f.control === "coil" ? "salt" : "coil";
			f.siege = 0;
			s.world.prices *= 1.1;
			fx(s, `${f.name} fell. The map redrew itself. Prices climbed.`);
			consequence(s, `front:${f.id}`);
		}
	}
}
function consequence(s, kind) {
	if (kind.startsWith("kill:")) {
		const id = kind.slice(5);
		const n = s.world.npcs.find((x) => x.id === id);
		if (!n) return;
		n.alive = false;
		s.world.graves.unshift({
			name: n.name,
			text: `Cut down by ${s.player.name}.`,
			hour: s.world.totalHours
		});
		s.player.karma -= 12;
		s.player.wanted += 8;
		rumor(s, `${s.player.name} killed ${n.name}.`, true);
		s.player.legend[n.place] = "Murderer";
		if (n.id === "shen") {
			s.kingdom.legitimacy -= 25;
			s.world.war = true;
			s.world.era = "Age of Succession";
			fx(s, "The king is dead. The Pale Coil splits. War walks the road.");
			imprint(s, "Slew a king");
		}
		const kin = s.world.npcs.find((x) => x.alive && x.faction === n.faction && x.id !== n.id);
		if (kin) {
			kin.nemesis = true;
			kin.relation -= 40;
			fx(s, `${kin.name} will not forget.`);
		}
	} else if (kind === "tax") {
		s.world.prices *= 1.08;
		s.kingdom.gold += 400;
		s.kingdom.legitimacy -= 4;
		fx(s, "Taxes rise. Merchants raise prices. Villagers start walking.");
	} else if (kind.startsWith("front:")) {
		s.kingdom.legitimacy -= 3;
		rumor(s, "The war map changed overnight.", true);
	}
}
function imprint(s, t) {
	if (!s.player.soul.includes(t)) s.player.soul.push(t);
}
function refreshBoard(s) {
	const here = s.player.place;
	const pool = [
		{
			id: uid(),
			title: "Listen at the well",
			where: here,
			hours: 1,
			gold: 0,
			qi: 4,
			text: "Gossip is a cultivation resource.",
			kind: "talk"
		},
		{
			id: uid(),
			title: "Work a shift",
			where: here,
			hours: 4,
			gold: Math.floor(10 * s.world.prices),
			qi: 0,
			text: "Hands before heaven.",
			kind: "work"
		},
		{
			id: uid(),
			title: "Meditate on the road dust",
			where: here,
			hours: 3,
			gold: 0,
			qi: 18,
			text: "The Dao hides in ordinary dirt.",
			kind: "dao"
		},
		{
			id: uid(),
			title: "Hunt a rumor",
			where: here,
			hours: 2,
			gold: 0,
			qi: 0,
			text: "News has legs. Catch it.",
			kind: "rumor"
		},
		{
			id: uid(),
			title: "Spar whoever looks proud",
			where: here,
			hours: 2,
			gold: 0,
			qi: 8,
			text: "Pride is a training dummy.",
			kind: "spar"
		}
	];
	const job = JOBS.find((j) => j.place === here);
	if (job) pool.unshift({
		id: uid(),
		title: job.name,
		where: here,
		hours: job.hours,
		gold: Math.floor(job.gold * s.world.prices),
		qi: 2,
		text: "Honest work. The ledger notices.",
		kind: "job"
	});
	s.world.activities = pool.slice(0, 6);
}
function doActivity(s, id) {
	const a = s.world.activities.find((x) => x.id === id);
	if (!a) return;
	spendHours(s, a.hours);
	s.player.gold += a.gold;
	s.player.qi += a.qi;
	fx(s, `${a.title}. +${a.gold}g +${a.qi} qi (${a.hours}h)`);
	if (a.kind === "dao" && Math.random() < .35) {
		s.player.qi += 20;
		imprint(s, "Dao from dust");
		fx(s, "A genuine insight. The Dao is not a button.");
	}
	if (a.kind === "spar") startCombat(s, nearby(s)[0]?.name ?? "Proud stranger");
	if (a.kind === "rumor" && s.world.rumors[0]) fx(s, "Heard: " + s.world.rumors[0].text);
}
function nearby(s) {
	return s.world.npcs.filter((n) => n.alive && n.place === s.player.place);
}
function talkTo(s, id, kind) {
	const n = s.world.npcs.find((x) => x.id === id);
	if (!n) return;
	spendHours(s, 1);
	n.memory.push(`${kind} @${Math.floor(s.world.totalHours)}`);
	n.memory = n.memory.slice(-8);
	if (kind === "kind") {
		n.relation += 8;
		n.loyalty += 3;
		fx(s, `${n.name} remembers the courtesy.`);
	}
	if (kind === "gift") {
		if (s.player.gold < 20) {
			fx(s, "Empty purse. They noticed.");
			n.relation -= 2;
			return;
		}
		s.player.gold -= 20;
		n.wealth += 20;
		n.relation += 14;
		fx(s, `A gift. ${n.name} weighs it.`);
	}
	if (kind === "insult") {
		n.relation -= 15;
		n.rival = true;
		fx(s, `${n.name} files you under enemy.`);
		if (n.relation < -30) n.nemesis = true;
	}
	if (kind === "recruit") {
		if (n.relation < 20) {
			fx(s, "They laugh. Not yet.");
			return;
		}
		if (!s.player.disciples.includes(n.id)) s.player.disciples.push(n.id);
		n.loyalty += 10;
		fx(s, `${n.name} bows — for now.`);
	}
	if (kind === "scheme") {
		s.world.sectPolitics[n.faction] = (s.world.sectPolitics[n.faction] ?? 10) + 4;
		n.relation += 5;
		fx(s, `A quiet word with ${n.name}. ${n.faction} gains a vote.`);
	}
}
function beginTravel(s, to) {
	const dest = PLACE[to];
	if (!dest) return;
	if (s.player.realm < dest.reqRealm) {
		fx(s, `Realm too low. Need ${realmLabel(dest.reqRealm)}.`);
		return;
	}
	const from = PLACE[s.player.place];
	const hours = dest.hours || 4;
	const gold = dest.gold;
	if (s.player.gold < gold) {
		fx(s, "Not enough gold for the road.");
		return;
	}
	s.player.gold -= gold;
	s.world.journey = {
		from: s.player.place,
		to,
		left: hours,
		total: hours,
		method: hours > 12 ? "cloud-boat" : "walk"
	};
	fx(s, `Departing ${from?.name ?? "here"} → ${dest.name}. ${hours}h, ${gold}g.`);
	s.screen = "world";
}
function pressOn(s) {
	const j = s.world.journey;
	if (!j) return;
	const step = Math.min(j.left, 6);
	spendHours(s, step);
	j.left -= step;
	if (Math.random() < .22) {
		const ev = [
			"Bandits on the ridge.",
			"A funeral procession blocks the road.",
			"You share tea with a nameless immortal.",
			"Rain. The Dao of water lectures you whether you asked."
		][Math.floor(Math.random() * 4)];
		fx(s, ev);
		s.player.qi += 6;
	}
	if (j.left <= 0) {
		s.player.place = j.to;
		s.world.journey = null;
		fx(s, `Arrived: ${PLACE[j.to]?.name}.`);
		refreshBoard(s);
	}
}
function cultivate(s, hours) {
	spendHours(s, hours);
	const gain = Math.floor(hours * (3 + s.player.realm) * FOUNDATION_MUL[s.player.foundation]);
	s.player.qi += gain;
	fx(s, `Seclusion ${hours}h. +${gain} qi.`);
}
function tryBreak(s) {
	const need = qiNeed(s.player.realm, s.player.stage);
	if (s.player.qi < need) {
		fx(s, `Need ${need} qi.`);
		return;
	}
	s.player.qi -= need;
	spendHours(s, 8);
	const roll = Math.random();
	const q = roll > .92 ? "transcendent" : roll > .7 ? "strong" : roll > .35 ? "steady" : "weak";
	s.player.lastBreak = q;
	if (s.player.stage >= 10) {
		s.player.realm += 1;
		s.player.stage = 1;
		s.player.lifespan = lifespanOf(s.player.realm, s.player.foundation);
		imprint(s, `Broke into ${realmLabel(s.player.realm)}`);
		fx(s, `MAJOR BREAKTHROUGH (${q}). ${realmLabel(s.player.realm, 1)}.`);
	} else {
		s.player.stage += 1;
		fx(s, `Stage breakthrough (${q}). ${realmLabel(s.player.realm, s.player.stage)}.`);
	}
}
function startCombat(s, foe, npc) {
	const php = 40 + s.player.realm * 18;
	const mhp = npc ? 30 + npc.realm * 16 : 28 + s.player.realm * 12;
	s.combat = {
		foe,
		hp: mhp,
		mhp,
		php,
		pmhp: php,
		log: [`${foe} draws.`],
		reward: 8 + (npc?.realm ?? 1) * 6
	};
	s.screen = "combat";
}
function combatHit(s, style) {
	const c = s.combat;
	if (!c) return;
	if (style === "flee") {
		spendHours(s, 1);
		s.combat = null;
		s.screen = "home";
		fx(s, "You left blood on the stones and kept your name.");
		return;
	}
	const atk = powerOf(s) * (style === "technique" ? 1.4 : 1);
	const dmg = Math.max(4, Math.floor(atk * (.6 + Math.random() * .6) / 8));
	c.hp -= dmg;
	c.log.push(`You deal ${dmg}.`);
	if (c.hp <= 0) {
		s.player.gold += c.reward;
		s.player.qi += 10;
		imprint(s, `Beat ${c.foe}`);
		fx(s, `Victory over ${c.foe}. +${c.reward}g.`);
		const n = s.world.npcs.find((x) => x.name === c.foe);
		if (n) {
			n.rival = true;
			n.relation -= 10;
		}
		s.combat = null;
		s.screen = "home";
		return;
	}
	const back = Math.max(3, Math.floor(c.mhp / 10 * (.5 + Math.random())));
	c.php -= back;
	c.log.push(`${c.foe} hits ${back}.`);
	if (c.php <= 0) {
		s.player.gold = Math.max(0, s.player.gold - 15);
		s.player.qi = Math.floor(s.player.qi * .8);
		imprint(s, "Tasted defeat");
		fx(s, `Defeat. ${c.foe} lets you crawl away.`);
		s.combat = null;
		s.screen = "home";
	}
}
function joinSect(s, id) {
	const sect = SECTS.find((x) => x.id === id);
	if (!sect) return;
	s.player.sect = id;
	s.player.rank = "outer";
	spendHours(s, 4);
	fx(s, `Joined ${sect.name} as Outer Disciple.`);
	rumor(s, `${displayName(s)} entered ${sect.name}.`, true);
}
function sectWork(s, hall) {
	spendHours(s, 4);
	if (hall === "library") {
		if (Math.random() < .3) {
			const t = "Hidden " + (DAO.find((d) => d.id === s.player.dao)?.name ?? "Dao") + " fragment";
			if (!s.player.techniques.includes(t)) s.player.techniques.push(t);
			fx(s, `A manual that was not supposed to be on the shelf: ${t}.`);
		} else fx(s, "Dust, commentary, one useful breath method. +12 qi.");
		s.player.qi += 12;
	} else if (hall === "train") {
		s.player.qi += 16;
		fx(s, "Sparring. Someone will remember how you fight.");
		const kael = s.world.npcs.find((n) => n.id === "kael");
		if (kael && kael.alive) {
			kael.rival = true;
			kael.relation -= 2;
		}
	} else if (hall === "alchemy") {
		s.player.gold -= 8;
		s.player.qi += 22;
		s.player.inventory.push("Qi pill");
		fx(s, "A bitter pill. It works.");
	} else if (hall === "treasury") {
		fx(s, `Sect purse: ${s.world.sectGold}g. You mark a leak in the ambition faction.`);
		s.world.sectPolitics.ambition = Math.max(5, (s.world.sectPolitics.ambition ?? 10) - 3);
	} else if (hall === "mission") {
		s.player.gold += 22;
		s.player.qi += 8;
		fx(s, "Contract complete. The world is slightly more afraid of your sect.");
	} else if (hall === "elder") {
		const f = FACTIONS[Math.floor(Math.random() * 4)];
		s.world.sectPolitics[f] = (s.world.sectPolitics[f] ?? 10) + 5;
		fx(s, `Council. You lean ${f}.`);
	} else if (hall === "court") {
		s.player.karma += 2;
		fx(s, "You judged a disciple dispute. Someone hates you fairly.");
	} else if (hall === "warhall") {
		s.world.war = true;
		fx(s, "War hall maps come out. The kingdom will hear of this.");
	} else if (hall === "leader") {
		if (s.player.rank === "elder" || s.player.rank === "leader") {
			s.player.mandate += 5;
			fx(s, "The seat listens.");
		} else fx(s, "The guards do not know your name yet.");
	}
}
function foundSect(s, name, doctrine) {
	if (s.player.realm < 4) {
		fx(s, "Realm 4 before you found a house.");
		return;
	}
	s.world.foundedSect = {
		name: name || "Unnamed Court",
		dao: s.player.dao,
		doctrine: doctrine || "Live."
	};
	s.player.sect = "founded";
	s.player.rank = "leader";
	spendHours(s, 24);
	s.world.era = "Age of Sect Wars";
	fx(s, `The ${s.world.foundedSect.name} opens its gates.`);
	rumor(s, `A new sect: ${s.world.foundedSect.name}.`, true);
}
function displayName(s) {
	return s.player.identityHidden && s.player.alias ? s.player.alias : s.player.name;
}
function march(s, frontId) {
	const f = s.world.fronts.find((x) => x.id === frontId);
	if (!f) return;
	s.world.war = true;
	spendHours(s, 10);
	f.siege += 20;
	const a = s.world.armies[0];
	if (a) {
		a.morale -= 4;
		a.supplies -= 8;
	}
	fx(s, `March on ${f.name}. Siege ${Math.min(100, f.siege)}%.`);
}
function joinBattle(s, frontId) {
	const f = s.world.fronts.find((x) => x.id === frontId);
	if (!f) return;
	startCombat(s, `${f.name} champion`);
}
function levy(s) {
	consequence(s, "tax");
	spendHours(s, 6);
}
function skipYears(s, years) {
	spendHours(s, years * HOURS_YEAR);
	s.player.qi += years * 8;
	fx(s, `${years} year${years > 1 ? "s" : ""} pass. The world did not wait.`);
	s.confirmSkip = null;
	if (years >= 10) {
		s.world.era = years >= 100 ? "Age of Immortals" : "Age of Sect Wars";
		rumor(s, `Historians skip to a new heading: ${s.world.era}.`, true);
	}
}
function previewSkip(s, years) {
	s.confirmSkip = {
		years,
		preview: `${years}y: you age ${years}, NPCs live and die, wars resolve, prices drift, rumors rot. Confirm?`
	};
}
function setSpeed(s, sp) {
	s.settings.timeSpeed = sp;
}
function tick(s, dtMs) {
	if (s.combat) return;
	const sp = s.settings.timeSpeed;
	if (!sp) return;
	const gameMsPerHour = MS_PER_GAME_DAY / 24;
	const add = dtMs * sp / gameMsPerHour;
	if (add <= 0) return;
	const next = s.world.lastSimHour + add;
	const whole = Math.floor(next) - Math.floor(s.world.lastSimHour);
	s.world.lastSimHour = next;
	if (whole > 0) {
		addHours(s, whole);
		if (s.world.journey) {
			s.world.journey.left = Math.max(0, s.world.journey.left - whole);
			if (s.world.journey.left <= 0) {
				s.player.place = s.world.journey.to;
				fx(s, `The road ended at ${PLACE[s.world.journey.to]?.name}.`);
				s.world.journey = null;
			}
		}
		simWorld(s, whole);
	}
}
function blackBuy(s, item, cost) {
	if (s.player.gold < cost) {
		fx(s, "The stall keeper smiles with too many teeth. No gold.");
		return;
	}
	s.player.gold -= cost;
	s.player.wanted += 6;
	s.player.inventory.push(item);
	spendHours(s, 2);
	fx(s, `Bought ${item} under the vein. Heaven may already know.`);
}
function awakenArtifact(s) {
	if (s.player.gold < 80) {
		fx(s, "The anvil wants 80 gold of respect.");
		return;
	}
	s.player.gold -= 80;
	spendHours(s, 8);
	const art = {
		id: uid(),
		name: [
			"Ashen Bell Shard",
			"Hour-Eater",
			"Coil-Silence"
		][s.player.artifacts.length % 3],
		mood: "testing you",
		loyalty: 30
	};
	s.player.artifacts.push(art);
	fx(s, `${art.name} opens an eye. It does not bow.`);
}
function digRuin(s) {
	spendHours(s, 6);
	s.player.qi += 10;
	if (Math.random() < .4) {
		s.player.inventory.push("Broken inscription");
		fx(s, "A language older than the Coil. You can almost read a warning.");
		imprint(s, "Touched a lost age");
	} else fx(s, "Dust. Bones. A child's toy that outlived a city.");
}
function enterInner(s) {
	spendHours(s, 5);
	s.inner = {
		title: "Heart-Demon Court",
		step: 0,
		path: [
			"A door of your own face.",
			"Kael stands inside it.",
			"You may forgive, fight, or walk around."
		]
	};
	s.screen = "inner";
}
function innerPick(s, i) {
	if (!s.inner) return;
	s.inner.step += 1;
	if (i === 0) {
		s.player.karma += 4;
		s.player.qi += 30;
		fx(s, "Forgiveness is a technique. +30 qi.");
	} else if (i === 1) {
		startCombat(s, "Heart-Demon Kael");
		return;
	} else {
		imprint(s, "Walked around a demon");
		fx(s, "Cowardice, or wisdom. The soul files both.");
	}
	s.inner = null;
	s.screen = "cultivate";
}
function sandbox(s, cmd) {
	if (cmd === "heaven") {
		s.player.realm = Math.max(5, s.player.realm);
		s.player.place = "time_market";
		fx(s, "Dropped into Hourglass Row.");
	}
	if (cmd === "divine") {
		s.player.realm = 8;
		s.player.place = "law_palace";
	}
	if (cmd === "chaos") {
		s.player.realm = 10;
		s.player.place = "chaos_shore";
	}
	if (cmd === "king") {
		s.player.origin = "royal";
		s.player.mandate = 70;
		s.kingdom.legitimacy = 80;
	}
	if (cmd === "war") s.world.war = true;
	if (cmd === "break") {
		s.player.qi = qiNeed(s.player.realm, s.player.stage) + 10;
		tryBreak(s);
	}
	if (cmd === "age") s.world.npcs.forEach((n) => {
		n.age += 10;
	});
	if (cmd === "rival") {
		const k = s.world.npcs.find((n) => n.id === "kael");
		if (k) k.rival = true;
	}
	if (cmd === "nemesis") {
		const k = s.world.npcs.find((n) => n.id === "lady");
		if (k) k.nemesis = true;
	}
	if (cmd === "gold") {
		s.player.gold += 500;
		s.kingdom.gold += 2e3;
	}
	if (cmd === "year") skipYears(s, 1);
}
function go(s, screen) {
	s.screen = screen;
}
var KEY = "path-of-the-immortal-v5";
function loadGame() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const s = JSON.parse(raw);
		if (!s || s.v !== 5) return null;
		return s;
	} catch {
		return null;
	}
}
function saveGame(s) {
	try {
		localStorage.setItem(KEY, JSON.stringify(s));
	} catch {}
}
function wipeSave() {
	localStorage.removeItem(KEY);
}
function persist(s) {
	saveGame(s);
	return { s: {
		...s,
		player: { ...s.player },
		world: { ...s.world }
	} };
}
var useGame = create((set, get) => ({
	s: null,
	boot: () => set({ s: loadGame() }),
	create: (o) => set(persist(newGame(o))),
	wipe: () => {
		wipeSave();
		set({ s: null });
	},
	go: (id) => {
		const s = get().s;
		if (!s) return;
		go(s, id);
		set(persist(s));
	},
	tick: (ms) => {
		const s = get().s;
		if (!s) return;
		tick(s, ms);
		set({ s });
	},
	act: (id) => {
		const s = get().s;
		if (!s) return;
		doActivity(s, id);
		set(persist(s));
	},
	talk: (id, k) => {
		const s = get().s;
		if (!s) return;
		talkTo(s, id, k);
		set(persist(s));
	},
	travel: (to) => {
		const s = get().s;
		if (!s) return;
		beginTravel(s, to);
		set(persist(s));
	},
	press: () => {
		const s = get().s;
		if (!s) return;
		pressOn(s);
		set(persist(s));
	},
	cult: (h) => {
		const s = get().s;
		if (!s) return;
		cultivate(s, h);
		set(persist(s));
	},
	brk: () => {
		const s = get().s;
		if (!s) return;
		tryBreak(s);
		set(persist(s));
	},
	hit: (st) => {
		const s = get().s;
		if (!s) return;
		combatHit(s, st);
		set(persist(s));
	},
	join: (sect) => {
		const s = get().s;
		if (!s) return;
		joinSect(s, sect);
		set(persist(s));
	},
	hall: (h) => {
		const s = get().s;
		if (!s) return;
		sectWork(s, h);
		set(persist(s));
	},
	found: (n, d) => {
		const s = get().s;
		if (!s) return;
		foundSect(s, n, d);
		set(persist(s));
	},
	warMarch: (id) => {
		const s = get().s;
		if (!s) return;
		march(s, id);
		set(persist(s));
	},
	warFight: (id) => {
		const s = get().s;
		if (!s) return;
		joinBattle(s, id);
		set(persist(s));
	},
	tax: () => {
		const s = get().s;
		if (!s) return;
		levy(s);
		set(persist(s));
	},
	speed: (sp) => {
		const s = get().s;
		if (!s) return;
		setSpeed(s, sp);
		set(persist(s));
	},
	askSkip: (y) => {
		const s = get().s;
		if (!s) return;
		previewSkip(s, y);
		set(persist(s));
	},
	doSkip: () => {
		const s = get().s;
		if (!s) return;
		if (s.confirmSkip) skipYears(s, s.confirmSkip.years);
		set(persist(s));
	},
	cancelSkip: () => {
		const s = get().s;
		if (!s) return;
		s.confirmSkip = null;
		set(persist(s));
	},
	buy: (item, c) => {
		const s = get().s;
		if (!s) return;
		blackBuy(s, item, c);
		set(persist(s));
	},
	artifact: () => {
		const s = get().s;
		if (!s) return;
		awakenArtifact(s);
		set(persist(s));
	},
	ruin: () => {
		const s = get().s;
		if (!s) return;
		digRuin(s);
		set(persist(s));
	},
	inner: () => {
		const s = get().s;
		if (!s) return;
		enterInner(s);
		set(persist(s));
	},
	innerGo: (i) => {
		const s = get().s;
		if (!s) return;
		innerPick(s, i);
		set(persist(s));
	},
	fight: (name) => {
		const s = get().s;
		if (!s) return;
		startCombat(s, name);
		set(persist(s));
	},
	box: (cmd) => {
		const s = get().s;
		if (!s) return;
		sandbox(s, cmd);
		set(persist(s));
	},
	hours: (h) => {
		const s = get().s;
		if (!s) return;
		spendHours(s, h);
		set(persist(s));
	}
}));
var NAV = [
	{
		id: "home",
		label: "Board",
		icon: House
	},
	{
		id: "world",
		label: "World",
		icon: Map
	},
	{
		id: "sect",
		label: "Sect",
		icon: Landmark
	},
	{
		id: "kingdom",
		label: "War",
		icon: Crown
	},
	{
		id: "heaven",
		label: "Heaven",
		icon: Cloud
	},
	{
		id: "more",
		label: "More",
		icon: Menu
	}
];
function GameApp() {
	const boot = useGame((g) => g.boot);
	const s = useGame((g) => g.s);
	const tick = useGame((g) => g.tick);
	const [creating, setCreating] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		boot();
	}, [boot]);
	(0, import_react.useEffect)(() => {
		let last = performance.now();
		let raf = 0;
		const loop = (now) => {
			const dt = Math.min(120, now - last);
			last = now;
			tick(dt);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [tick]);
	if (creating) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Create, { onDone: () => setCreating(false) });
	if (!s) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, { onBegin: () => setCreating(true) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
function Title({ onBegin }) {
	const s = useGame((g) => g.s);
	const go = useGame((g) => g.go);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-hidden bg-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/art/key-art.png",
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scrim absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-h-dvh flex-col justify-end px-5 pb-10 pt-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs tracking-[0.35em] text-gold",
						children: "PATH OF THE IMMORTAL"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 max-w-sm font-display text-4xl leading-tight text-gold-soft",
						children: "One life. A world that does not wait."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-md text-sm text-bone/80",
						children: "Cultivate, scheme, march, and live in Heaven. The calendar is slow. The consequences are not."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "min-h-12 rounded-lg bg-gold px-4 font-display text-ink",
							onClick: onBegin,
							children: "Begin a life"
						}), s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "min-h-12 rounded-lg border border-gold/40 px-4 text-gold-soft",
							onClick: () => go("home"),
							children: "Continue"
						}) : null]
					})
				]
			})
		]
	});
}
function Create({ onDone }) {
	const create = useGame((g) => g.create);
	const [name, setName] = (0, import_react.useState)("");
	const [gender, setGender] = (0, import_react.useState)("male");
	const [origin, setOrigin] = (0, import_react.useState)("commoner");
	const [dao, setDao] = (0, import_react.useState)("sword");
	const art = portraitOf(gender, origin);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-ink px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs tracking-[0.3em] text-gold",
				children: "NEW LIFE"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-2xl text-gold-soft",
				children: "Who walks the mud?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: art,
				alt: "",
				className: "mt-4 h-64 w-full rounded-xl object-cover object-top"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mt-4 block text-xs text-muted",
				children: "Name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: name,
				onChange: (e) => setName(e.target.value),
				placeholder: "Unnamed",
				className: "mt-1 min-h-12 w-full rounded-lg border border-line bg-paper px-3 text-bone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [["male", "female"].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: gender === g,
					onClick: () => setGender(g),
					children: g
				}, g)), ["commoner", "royal"].map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: origin === o,
					onClick: () => setOrigin(o),
					children: o
				}, o))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted",
				children: "Dao"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 flex flex-wrap gap-2",
				children: DAO.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: dao === d.id,
					onClick: () => setDao(d.id),
					children: d.name
				}, d.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "mt-6 min-h-12 w-full rounded-lg bg-gold font-display text-ink",
				onClick: () => {
					create({
						name,
						gender,
						origin,
						dao
					});
					onDone();
				},
				children: "Step into the year 614"
			})
		]
	});
}
function Chip({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick,
		className: `min-h-11 rounded-lg border px-3 text-sm capitalize ${on ? "border-gold bg-gold/15 text-gold-soft" : "border-line text-muted"}`,
		children
	});
}
function Shell() {
	const s = useGame((g) => g.s);
	const go = useGame((g) => g.go);
	const speed = useGame((g) => g.speed);
	const press = useGame((g) => g.press);
	const loc = PLACE[s.player.place];
	const cal = calendar(s.world.totalHours);
	const art = loc?.art ?? "/art/key-art.png";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto flex min-h-dvh max-w-lg flex-col bg-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-36 shrink-0 overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: art,
						alt: "",
						className: "h-full w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scrim absolute inset-0" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-0 bottom-0 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs tracking-widest text-gold",
							children: loc?.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-bone/80",
							children: [
								"Y",
								cal.year,
								".",
								String(cal.month).padStart(2, "0"),
								".",
								String(cal.day).padStart(2, "0"),
								" · ",
								String(cal.hour).padStart(2, "0"),
								":00 · ",
								s.world.era
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-2 border-b border-line px-3 py-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "text-left",
					onClick: () => go("character"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-gold-soft",
						children: displayName(s)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-muted",
						children: realmLabel(s.player.realm, s.player.stage)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [s.player.gold, "g"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [
							"crown ",
							s.kingdom.gold,
							"g"
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1 border-b border-line px-2 py-1",
				children: [[
					0,
					1,
					2,
					5
				].map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => speed(sp),
					className: `flex min-h-10 min-w-10 items-center justify-center rounded-md text-xs ${s.settings.timeSpeed === sp ? "bg-gold text-ink" : "text-muted"}`,
					children: sp === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-3.5" }) : sp === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5" }) : `${sp}×`
				}, sp)), s.world.journey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: press,
					className: "ml-auto min-h-10 rounded-md bg-gold/20 px-3 text-xs text-gold-soft",
					children: [
						"Press on · ",
						s.world.journey.left,
						"h"
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 py-3 pb-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {})
			}),
			s.confirmSkip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipModal, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 mx-auto flex max-w-lg border-t border-line bg-ink/95",
				children: NAV.map((n) => {
					const Icon = n.icon;
					const on = s.screen === n.id || n.id === "kingdom" && s.screen === "war";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => go(n.id),
						className: `flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-[10px] ${on ? "text-gold" : "text-muted"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), n.label]
					}, n.id);
				})
			})
		]
	});
}
function Screen() {
	switch (useGame((g) => g.s).screen) {
		case "home": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeBoard, {});
		case "character": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Character, {});
		case "cultivate": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cultivate, {});
		case "world": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(World, {});
		case "heaven": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heaven, {});
		case "divine": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layer, { layer: "divine" });
		case "primordial": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layer, { layer: "primordial" });
		case "sect": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sect, {});
		case "kingdom":
		case "war": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(War, {});
		case "people": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(People, {});
		case "market": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Market, {});
		case "black": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Black, {});
		case "society": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Society, {});
		case "dream": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dream, {});
		case "inner": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inner, {});
		case "ruins": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ruins, {});
		case "companion": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Companions, {});
		case "artifact": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Artifacts, {});
		case "rumor": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rumors, {});
		case "identity": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Identity, {});
		case "combat": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Combat, {});
		case "sandbox": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sandbox, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(More, {});
	}
}
function Card({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `mb-3 rounded-xl border border-line bg-paper p-3 ${className}`,
		children
	});
}
function HomeBoard() {
	const s = useGame((g) => g.s);
	const act = useGame((g) => g.act);
	const go = useGame((g) => g.go);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-xs text-muted",
			children: PLACE[s.player.place]?.blurb
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "What you can do"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 space-y-2",
			children: s.world.activities.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => act(a.id),
				className: "flex min-h-12 w-full items-center justify-between rounded-lg border border-line px-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm text-bone",
					children: a.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] text-muted",
					children: [
						a.hours,
						"h · ",
						a.gold,
						"g · ",
						a.qi,
						" qi"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-gold text-xs",
					children: "Do"
				})]
			}) }, a.id))
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("cultivate"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "size-4" }),
					label: "Cultivate"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("people"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }),
					label: "People here"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("character"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, { className: "size-4" }),
					label: "Identity"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("rumor"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-4" }),
					label: "Rumors"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Log, {})
	] });
}
function Quick({ onClick, icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		className: "flex min-h-12 items-center gap-2 rounded-xl border border-line bg-paper px-3 text-sm text-bone",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-gold",
			children: icon
		}), label]
	});
}
function Log() {
	const s = useGame((g) => g.s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-sm text-gold",
		children: "Chronicle"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 space-y-1 text-xs text-muted",
		children: s.log.slice(0, 8).map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: l }, i))
	})] });
}
function Character() {
	const s = useGame((g) => g.s);
	const art = portraitOf(s.player.gender, s.player.origin);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: art,
		alt: "",
		className: "mb-3 h-72 w-full rounded-xl object-cover object-top"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg text-gold-soft",
			children: displayName(s)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				realmLabel(s.player.realm, s.player.stage),
				" · ",
				s.player.foundation,
				" foundation"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm",
			children: [
				"Age ",
				s.player.age.toFixed(1),
				" / ",
				s.player.lifespan,
				" · Power ",
				powerOf(s)
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: [
				"Dao ",
				s.player.dao,
				" · Karma ",
				s.player.karma,
				" · Mandate ",
				s.player.mandate
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-xs text-muted",
			children: ["Soul imprints: ", s.player.soul.join(" · ") || "none yet"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs text-muted",
			children: ["Techniques: ", s.player.techniques.join(", ")]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs text-gold",
			children: ["Legend here: ", s.player.legend[s.player.place] ?? "Unknown wanderer"]
		})
	] })] });
}
function Cultivate() {
	const s = useGame((g) => g.s);
	const cult = useGame((g) => g.cult);
	const brk = useGame((g) => g.brk);
	const inner = useGame((g) => g.inner);
	const ask = useGame((g) => g.askSkip);
	const need = qiNeed(s.player.realm, s.player.stage);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-display text-sm text-gold",
			children: ["Foundation · ", s.player.foundation]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				"Last break: ",
				s.player.lastBreak,
				". Realm is not total power."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm",
			children: [
				s.player.qi,
				" / ",
				need,
				" qi"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-2 overflow-hidden rounded bg-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-gold",
				style: { width: `${Math.min(100, s.player.qi / need * 100)}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-3 gap-2",
			children: [
				7,
				30,
				90
			].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => cult(h * 24),
				className: "min-h-12 rounded-lg border border-line text-xs",
				children: [
					"Seclude ",
					h,
					"d"
				]
			}, h))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: brk,
			className: "mt-2 min-h-12 w-full rounded-lg bg-gold font-display text-ink",
			children: "Attempt breakthrough"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: inner,
			className: "mt-2 min-h-12 w-full rounded-lg border border-gold/40 text-gold",
			children: "Enter meditation"
		})
	] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Skip time"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: "Requires confirmation. The world keeps living."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid grid-cols-3 gap-2",
			children: [
				1,
				10,
				100
			].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => ask(y),
				className: "min-h-12 rounded-lg border border-line text-xs",
				children: [y, " year"]
			}, y))
		})
	] })] });
}
function World() {
	const s = useGame((g) => g.s);
	const travel = useGame((g) => g.travel);
	const dests = (PLACE[s.player.place]?.adj ?? []).map((id) => PLACE[id]).filter(Boolean);
	const all = PLACES.filter((p) => p.layer === "mortal");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-xs text-muted",
			children: "Travel is hours, gold, and events — not a teleport."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Roads from here"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 space-y-2",
			children: dests.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => travel(p.id),
				className: "flex min-h-12 w-full items-center justify-between rounded-lg border border-line px-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm",
					children: p.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] text-muted",
					children: [
						p.hours || 3,
						"h · ",
						p.gold,
						"g · ",
						p.layer
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-gold",
					children: "Walk"
				})]
			}) }, p.id))
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Mortal map"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid grid-cols-2 gap-2",
			children: all.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => travel(p.id),
				className: "overflow-hidden rounded-lg border border-line text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: p.art,
					alt: "",
					className: "h-16 w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block px-2 py-1 text-[11px]",
					children: p.name
				})]
			}, p.id))
		})] })
	] });
}
function Heaven() {
	const s = useGame((g) => g.s);
	const travel = useGame((g) => g.travel);
	const go = useGame((g) => g.go);
	const here = PLACE[s.player.place];
	const districts = PLACES.filter((p) => p.layer === "heaven");
	const inHeaven = here?.layer === "heaven";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/art/heaven-market.png",
			alt: "",
			className: "mb-3 h-40 w-full rounded-xl object-cover"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-sm text-bone",
			children: "Heaven is a city. Districts, jobs, law, and a market that sells hours."
		}),
		!inHeaven ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => travel("heaven_gate"),
			className: "mb-3 min-h-12 w-full rounded-lg bg-gold font-display text-ink",
			children: "Ascend to Heaven Gate (realm 5+)"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Walk the city"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 space-y-2",
			children: districts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => travel(p.id),
				className: `flex min-h-12 w-full items-center justify-between rounded-lg border px-3 text-left ${p.id === s.player.place ? "border-gold" : "border-line"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm",
					children: p.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] text-muted",
					children: [
						p.kind,
						" · ",
						p.blurb
					]
				})] })
			}) }, p.id))
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("people"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }),
					label: "Souls here"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("black"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-4" }),
					label: "Under-Vein"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("divine"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-4" }),
					label: "Divine"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
					onClick: () => go("primordial"),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-4" }),
					label: "Primordial"
				})
			]
		})
	] });
}
function Layer({ layer }) {
	const travel = useGame((g) => g.travel);
	const list = PLACES.filter((p) => p.layer === layer);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 text-sm",
		children: layer === "divine" ? "A civilization of verdicts and thunder-cities." : "The world before names. It still wants them back."
	}), list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => travel(p.id),
		className: "mb-2 w-full overflow-hidden rounded-xl border border-line text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: p.art,
			alt: "",
			className: "h-24 w-full object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-gold",
				children: p.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: p.blurb
			})]
		})]
	}, p.id))] });
}
function Sect() {
	const s = useGame((g) => g.s);
	const join = useGame((g) => g.join);
	const hall = useGame((g) => g.hall);
	const [nm, setNm] = (0, import_react.useState)("");
	const [doc, setDoc] = (0, import_react.useState)("");
	const found = useGame((g) => g.found);
	const sect = SECTS.find((x) => x.id === s.player.sect);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!s.player.sect ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-sm text-gold",
		children: "Join a house"
	}), SECTS.filter((x) => x.place === s.player.place || x.id === "silent_blade").map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => join(x.id),
		className: "mt-2 min-h-12 w-full rounded-lg border border-line px-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm",
			children: x.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] text-muted",
			children: x.motto
		})]
	}, x.id))] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: sect?.name ?? s.world.foundedSect?.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				"Rank ",
				s.player.rank,
				" · Treasury ",
				s.world.sectGold,
				"g"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-xs",
			children: ["Factions: ", Object.entries(s.world.sectPolitics).map(([k, v]) => `${k} ${v}`).join(" · ")]
		})
	] }), HALLS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => hall(h.id),
		className: "mb-2 flex min-h-12 w-full items-center justify-between rounded-xl border border-line bg-paper px-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm",
			children: h.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] text-muted",
			children: h.act
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-gold",
			children: "4h"
		})]
	}, h.id))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Found your own"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: nm,
			onChange: (e) => setNm(e.target.value),
			placeholder: "Sect name",
			className: "mt-2 min-h-11 w-full rounded-lg border border-line bg-ink px-3 text-sm"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: doc,
			onChange: (e) => setDoc(e.target.value),
			placeholder: "Doctrine",
			className: "mt-2 min-h-11 w-full rounded-lg border border-line bg-ink px-3 text-sm"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => found(nm, doc),
			className: "mt-2 min-h-12 w-full rounded-lg border border-gold/40 text-gold",
			children: "Raise a banner (realm 4+)"
		})
	] })] });
}
function War() {
	const s = useGame((g) => g.s);
	const march = useGame((g) => g.warMarch);
	const fight = useGame((g) => g.warFight);
	const tax = useGame((g) => g.tax);
	if (!(s.player.origin === "royal" || s.player.realm >= 4 || s.player.mandate > 10)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: "Citizen levy"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "You are not the crown. You can still volunteer."
		}),
		s.world.fronts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => fight(f.id),
			className: "mt-2 min-h-12 w-full rounded-lg border border-line text-sm",
			children: ["Volunteer at ", f.name]
		}, f.id))
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-gold",
				children: "Two purses"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Personal ",
					s.player.gold,
					"g · Treasury ",
					s.kingdom.gold,
					"g · Tax ",
					s.kingdom.tax,
					"% · Legitimacy ",
					s.kingdom.legitimacy
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: tax,
				className: "mt-2 min-h-12 w-full rounded-lg border border-line",
				children: "Raise taxes (prices will answer)"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm text-gold",
				children: "Campaign map"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: s.world.war ? "War is live. Time moves the fronts." : "Peace is a rumor with an expiration."
			}),
			s.world.fronts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 rounded-lg border border-line p-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						f.name,
						" · ",
						f.control,
						" · siege ",
						Math.floor(f.siege),
						"%"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => march(f.id),
						className: "min-h-11 flex-1 rounded-md bg-gold/20 text-xs text-gold",
						children: "March 10h"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => fight(f.id),
						className: "min-h-11 flex-1 rounded-md border border-line text-xs",
						children: "Join battle"
					})]
				})]
			}, f.id))
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm text-gold",
			children: "Armies"
		}), s.world.armies.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs",
			children: [
				a.name,
				" · ",
				a.size,
				" · morale ",
				a.morale,
				" · supply ",
				a.supplies,
				" · ",
				a.loc
			]
		}, a.id))] })
	] });
}
function People() {
	const s = useGame((g) => g.s);
	const talk = useGame((g) => g.talk);
	const list = nearby(s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mb-2 text-xs text-muted",
		children: [list.length, " souls on this street. They have jobs, hours, and memory."]
	}), list.slice(0, 12).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 overflow-hidden rounded-xl border border-line bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3 p-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: n.portrait,
				alt: "",
				className: "h-20 w-16 rounded-md object-cover object-top"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm text-gold-soft",
						children: n.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-muted",
						children: [
							n.title,
							" · ",
							n.job,
							" · now ",
							n.schedule
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-muted",
						children: [
							"Age ",
							n.age.toFixed(0),
							" · realm ",
							n.realm,
							" · ",
							n.wealth,
							"g · ",
							n.destiny
						]
					}),
					n.memory[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-gold",
						children: ["Remembers: ", n.memory[n.memory.length - 1]]
					}) : null,
					n.rival ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-blood",
						children: "Rival"
					}) : null,
					n.nemesis ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-blood",
						children: "Nemesis"
					}) : null
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-5 gap-1 p-2 pt-0",
			children: [
				"kind",
				"gift",
				"insult",
				"recruit",
				"scheme"
			].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => talk(n.id, k),
				className: "min-h-10 rounded-md border border-line text-[10px] capitalize",
				children: k
			}, k))
		})]
	}, n.id))] });
}
function Market() {
	const act = useGame((g) => g.act);
	const s = useGame((g) => g.s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: "Hourglass Row"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				"Prices ×",
				s.world.prices.toFixed(2),
				". Time also obeys coin."
			]
		}),
		s.world.activities.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => act(a.id),
			className: "mt-2 min-h-12 w-full rounded-lg border border-line text-sm",
			children: a.title
		}, a.id))
	] });
}
function Black() {
	const buy = useGame((g) => g.buy);
	const s = useGame((g) => g.s);
	const go = useGame((g) => g.go);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => go("heaven"),
			className: "mb-2 text-xs text-gold",
			children: "← Heaven"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/art/heaven-market.png",
			alt: "",
			className: "mb-3 h-32 w-full rounded-xl object-cover opacity-80"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-gold",
				children: "Under-Vein"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					"Wanted ",
					s.player.wanted,
					". Heaven law ",
					s.world.heavenLaw,
					"."
				]
			}),
			[
				["Forbidden fire sutra", 90],
				["False name papers", 45],
				["Stolen hourglass", 120],
				["Assassin contract", 70]
			].map(([item, cost]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => buy(String(item), Number(cost)),
				className: "mt-2 min-h-12 w-full rounded-lg border border-line text-left px-3 text-sm",
				children: [
					item,
					" · ",
					cost,
					"g"
				]
			}, String(item)))
		] })
	] });
}
function Society() {
	const hours = useGame((g) => g.hours);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: "Ashen Bell Society"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "A hidden order. Bells remember debts."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => hours(5),
			className: "mt-3 min-h-12 w-full rounded-lg bg-gold text-ink",
			children: "Take a silent contract (5h)"
		})
	] });
}
function Dream() {
	const s = useGame((g) => g.s);
	const go = useGame((g) => g.go);
	if (!s.dream) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "The moon is quiet. Sleep somewhere long enough."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: s.dream.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm",
			children: s.dream.text
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: "Dreams are not always honest."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => go("home"),
			className: "mt-3 min-h-12 w-full rounded-lg border border-line",
			children: "Wake"
		})
	] });
}
function Inner() {
	const s = useGame((g) => g.s);
	const pick = useGame((g) => g.innerGo);
	if (!s.inner) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "No inner landscape open."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: s.inner.title
		}),
		s.inner.path.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm",
			children: p
		}, p)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => pick(0),
					className: "min-h-12 rounded-lg bg-gold text-ink",
					children: "Forgive"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => pick(1),
					className: "min-h-12 rounded-lg border border-line",
					children: "Fight"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => pick(2),
					className: "min-h-12 rounded-lg border border-line",
					children: "Walk around"
				})
			]
		})
	] });
}
function Ruins() {
	const ruin = useGame((g) => g.ruin);
	const s = useGame((g) => g.s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: "Lost civilizations"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Cinder, Unmade City, First Dark. Dig. Pieces connect."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: ruin,
			className: "mt-3 min-h-12 w-full rounded-lg bg-gold text-ink",
			children: "Excavate 6h"
		})
	] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-xs text-muted",
		children: ["Pack: ", s.player.inventory.join(", ") || "empty"]
	}) })] });
}
function Companions() {
	const s = useGame((g) => g.s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: "Companions & disciples"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: ["Master: ", s.player.master || "none"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: ["Disciples: ", s.player.disciples.length]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: "Recruit from People. Loyalty is treatment, not a number that never moves."
		})
	] });
}
function Artifacts() {
	const s = useGame((g) => g.s);
	const artifact = useGame((g) => g.artifact);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick: artifact,
		className: "mb-3 min-h-12 w-full rounded-lg bg-gold text-ink",
		children: "Awaken an artifact (80g, 8h)"
	}), s.player.artifacts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-gold",
		children: a.name
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm",
		children: [
			a.mood,
			" · loyalty ",
			a.loyalty
		]
	})] }, a.id))] });
}
function Rumors() {
	const s = useGame((g) => g.s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-gold",
		children: "Rumor mill"
	}), s.world.rumors.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-2 text-sm",
		children: [
			r.text,
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-muted",
				children: [
					"(",
					r.age.toFixed(1),
					"d old)"
				]
			})
		]
	}, i))] });
}
function Identity() {
	const s = useGame((g) => g.s);
	const hours = useGame((g) => g.hours);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: "False name"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: [
				"Now: ",
				displayName(s),
				" ",
				s.player.identityHidden ? "(hidden)" : "(true)"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => {
				s.player.identityHidden = !s.player.identityHidden;
				s.player.alias = s.player.alias || "Dust-Walker";
				hours(2);
			},
			className: "mt-3 min-h-12 w-full rounded-lg border border-line",
			children: "Toggle alias (2h)"
		})
	] });
}
function Combat() {
	const s = useGame((g) => g.s);
	const hit = useGame((g) => g.hit);
	const c = s.combat;
	if (!c) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No fight." });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: c.foe
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs",
			children: [
				"Them ",
				c.hp,
				"/",
				c.mhp,
				" · You ",
				c.php,
				"/",
				c.pmhp
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-2 rounded bg-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-blood",
				style: { width: `${c.hp / c.mhp * 100}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => hit("strike"),
					className: "min-h-12 rounded-lg bg-gold text-ink",
					children: "Strike"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => hit("technique"),
					className: "min-h-12 rounded-lg border border-line",
					children: "Art"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => hit("flee"),
					className: "min-h-12 rounded-lg border border-line",
					children: "Flee"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 text-xs text-muted",
			children: c.log.slice(-6).map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: l }, i))
		})
	] });
}
function More() {
	const go = useGame((g) => g.go);
	const wipe = useGame((g) => g.wipe);
	const [taps, setTaps] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		[
			{
				id: "cultivate",
				label: "Cultivate / time"
			},
			{
				id: "people",
				label: "NPC lives"
			},
			{
				id: "character",
				label: "Identity card"
			},
			{
				id: "market",
				label: "Markets"
			},
			{
				id: "black",
				label: "Black market"
			},
			{
				id: "society",
				label: "Secret society"
			},
			{
				id: "dream",
				label: "Dreams"
			},
			{
				id: "ruins",
				label: "Archaeology"
			},
			{
				id: "companion",
				label: "Disciples"
			},
			{
				id: "artifact",
				label: "Artifacts"
			},
			{
				id: "rumor",
				label: "Rumors"
			},
			{
				id: "identity",
				label: "False identity"
			},
			{
				id: "divine",
				label: "Divine Realm"
			},
			{
				id: "primordial",
				label: "Primordial Chaos"
			}
		].map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => go(it.id),
			className: "mb-2 min-h-12 w-full rounded-xl border border-line bg-paper px-3 text-left text-sm",
			children: it.label
		}, it.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => {
				const n = taps + 1;
				setTaps(n);
				if (n >= 7) go("sandbox");
			},
			className: "mt-4 w-full text-center text-[10px] text-muted",
			children: "Year 614 · Path of the Immortal"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: wipe,
			className: "mt-2 w-full text-center text-[10px] text-blood",
			children: "End this life"
		})
	] });
}
function Sandbox() {
	const box = useGame((g) => g.box);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-gold",
			children: "Developer sandbox"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: "Hidden. Tests the world without grinding."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-2 gap-2",
			children: [
				"heaven",
				"divine",
				"chaos",
				"king",
				"war",
				"break",
				"age",
				"rival",
				"nemesis",
				"gold",
				"year"
			].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => box(c),
				className: "min-h-11 rounded-lg border border-line text-xs",
				children: c
			}, c))
		})
	] });
}
function SkipModal() {
	const s = useGame((g) => g.s);
	const yes = useGame((g) => g.doSkip);
	const no = useGame((g) => g.cancelSkip);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/70 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-2xl border border-gold/40 bg-paper p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-gold",
					children: [
						"Skip ",
						s.confirmSkip?.years,
						" year(s)?"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-bone",
					children: s.confirmSkip?.preview
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: no,
						className: "min-h-12 rounded-lg border border-line",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: yes,
						className: "min-h-12 rounded-lg bg-gold text-ink",
						children: "Confirm"
					})]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
